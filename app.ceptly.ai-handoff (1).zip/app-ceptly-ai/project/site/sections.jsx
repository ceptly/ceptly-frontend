/* sections.jsx — Ceptly hi-fi landing page (Approach A) */
const { useState, useEffect, useRef } = React;

/* ---- lucide icon (matches DS: 2px stroke, color-inherit) ---- */
function Icon({ name, size = 16, className = "", color }) {
  const ref = useRef(null);
  useEffect(() => {
    const host = ref.current;
    if (!host || !window.lucide) return;
    host.innerHTML = "";
    const i = document.createElement("i");
    i.setAttribute("data-lucide", name);
    i.setAttribute("width", size);
    i.setAttribute("height", size);
    i.setAttribute("stroke-width", "2");
    if (color) i.setAttribute("color", color);
    host.appendChild(i);
    window.lucide.createIcons({ root: host });
  }, [name, size, color]);
  return <span ref={ref} className={"ic " + className} style={{ width: size, height: size, display: "inline-flex" }} />;
}

/* ---- brand mark + wordmark ---- */
function Brand({ word = true }) {
  return (
    <a href="#top" className="brand">
      <img className="logo-l" src="assets/parallax-light.png" alt="Ceptly" />
      <img className="logo-d" src="assets/parallax-dark.png" alt="Ceptly" />
      {word && <span className="word">Ceptly</span>}
    </a>);

}

/* ---- header ---- */
function Header({ onToggleTheme, dark }) {
  return (
    <header className="hd">
      <div className="container hd-in">
        <Brand />
        <nav className="nav">
          <a href="#how">How it works</a>
          <a href="#features">Features</a>
          <a href="#pricing">Pricing</a>
          <a href="#faq">FAQ</a>
        </nav>
        <div className="hd-cta">
          <button className="btn btn-ghost" onClick={onToggleTheme} aria-label="Toggle theme" title="Toggle light / dark">
            <Icon name={dark ? "sun" : "moon"} size={17} />
          </button>
          <a className="btn btn-ghost" href="#">Sign in</a>
          <a className="btn btn-pill btn-sm" href="#">Create account</a>
        </div>
      </div>
    </header>);

}

/* ---- hero ---- */
function Hero() {
  return (
    <section className="hero" id="top">
      <div className="hero-bg">
        <div className="hero-grid" />
        <div className="hero-dots" />
        <img className="hero-mark logo-l" src="assets/parallax-light.png" alt="" aria-hidden="true" />
        <img className="hero-mark logo-d" src="assets/parallax-dark.png" alt="" aria-hidden="true" />
      </div>
      <div className="container hero-in">
        <span className="eyebrow"><Icon name="sparkles" size={14} /> AI chief of staff for flat teams</span>
        <h1>Your team&rsquo;s AI chief of staff</h1>
        <p className="sub">
          Set up schedules in chat. ICs answer in Slack. Leaders get rollups, team insights,
          and one-off reach-out&mdash;<b>without status meetings</b>.
        </p>
        <div className="hero-actions">
          <a className="btn btn-cta" href="#">Create account &mdash; start free <Icon name="arrow-right" size={16} /></a>
          <a className="btn btn-outline" href="#how">See how it works</a>
        </div>
        <p className="nocard">No credit card required &middot; 10-day free trial</p>
      </div>
    </section>);

}

/* ---- embedded app preview (forked from DS marketing kit) ---- */
function AppPreview() {
  return (
    <div className="pv-root" style={{ minHeight: 460 }}>
      <div className="pv-top">
        <div className="pv-topin">
          <div className="lf">
            <img className="mk" src="assets/parallax.png" alt="Ceptly" />
            <div className="pv-tabs">
              <span className="pv-nav">Activity</span>
              <span className="pv-nav active">Chat</span>
              <span className="pv-nav">Team</span>
              <span className="pv-nav">Settings</span>
            </div>
          </div>
          <span className="pv-me">ME</span>
        </div>
      </div>
      <div className="pv-body">
        <div className="pv-msg user"><span className="pv-bubble pv-user">Schedule a stand-up meeting with <span style={{ color: "#69C35B" }}>@Michael</span> <span style={{ color: "#69C35B" }}>@Trey</span> and <span style={{ color: "#69C35B" }}>@Reagan</span> every weekday at 9am in <span style={{ color: "#69C35B" }}>#tech</span>. </span></div>
        <div style={{ display: "flex", gap: 10 }}>
          <span className="pv-spark"><Icon name="sparkles" size={14} color="#56FF3C" /></span>
          <div style={{ display: "flex", flexDirection: "column", gap: 8, maxWidth: "82%" }}>
            <span className="pv-who">Ceptly</span>
            <div className="pv-activity">
              <span>Building reach-out plan &middot; 2s</span>
              <div className="pv-step"><Icon name="sparkles" size={14} color="#56FF3C" /> Matching roster members</div>
              <div className="pv-step"><img src="assets/integrations-slack.png" alt="" /> Loading Slack Channels</div>
            </div>
            <div className="pv-bubble pv-ai">Here’s a plan for your daily standup in Slack. Review the details below and start when you’re ready.</div>
            <div className="pv-proposal">
              <div className="pv-proposal-head"><Icon name="message-square" size={13} /> Standup &middot; Slack Channel</div>
              <div className="pv-eyebrow">Gather information</div>
              <p className="pv-recip"><b>Recipients: Trey Chen, Michael Bolton & Reagan Dunkle</b></p>
              <p className="pv-detail">Goal: Gather updates, blockers, ETA on current work, and questions.</p>
              <span className="pv-ctab">Publish schedule <Icon name="arrow-right" size={13} /></span>
            </div>
          </div>
        </div>
      </div>
      <div className="pv-prompt">
        <div className="pv-tag"><span className="pv-tag-badge">Standup</span></div>
        <div className="pv-prompt-text">Ask about your team &mdash; @ for people, # for channels&hellip;</div>
        <div className="pv-prompt-bar">
          <span className="pv-auto">Auto <Icon name="chevron-down" size={13} /></span>
          <span className="pv-send"><Icon name="arrow-up" size={14} /></span>
        </div>
      </div>
    </div>);
}

/* ---- product showcase window ---- */
function Showcase() {
  return (
    <div className="showcase">
      <div className="win">
        <div className="win-bar">
          <div className="tl"><i></i><i></i><i></i></div>
          <span className="addr">app.ceptly.ai/agents/new</span>
          <span className="demo-hint"><Icon name="mouse-pointer-click" size={13} /> Interactive</span>
        </div>
        <iframe className="demo-frame" src="../app/Deploy%20Demo%20B.html" title="Deploy an agent — live demo"></iframe>
      </div>
    </div>);

}

/* ---- mid-page demo: scheduling a standup in chat ---- */
function DeployDemo() {
  return (
    <section className="section" id="demo">
      <div className="container">
        <div className="shead">
          <span className="kicker">In the app</span>
          <h2>Set up a standup in plain English</h2>
          <p>Describe the cadence in chat. Ceptly drafts a publishable schedule and runs the check-ins in Slack&mdash;no forms, no status meetings.</p>
        </div>
        <div className="demo-wrap">
          <div className="win">
            <div className="win-bar">
              <div className="tl"><i></i><i></i><i></i></div>
              <span className="addr">app.ceptly.ai</span>
            </div>
            <AppPreview />
          </div>
        </div>
      </div>
    </section>);

}

/* ---- integrations strip ---- */
const INTEGRATIONS = [
{ name: "Slack", light: "assets/integrations/slack.png", dark: "assets/integrations/slack.png" },
{ name: "Linear", light: "assets/integrations/linear-light.png", dark: "assets/integrations/linear-dark.png" },
{ name: "Jira", light: "assets/integrations/Jira_icon.png", dark: "assets/integrations/Jira_icon.png" },
{ name: "Monday", light: "assets/integrations/monday.png", dark: "assets/integrations/monday.png" }];

function Integrations() {
  return (
    <section className="section tight">
      <div className="container integ">
        <span className="integ-label">Works with the tools your team already uses</span>
        <div className="integ-row">
          {INTEGRATIONS.map((it) =>
          <span className="chip" key={it.name}>
              <img className="logo-l" src={it.light} alt="" />
              <img className="logo-d" src={it.dark} alt="" />
              {it.name}
            </span>
          )}
          <span className="chip more">+ more</span>
        </div>
      </div>
    </section>);

}

/* ---- how it works ---- */
const STEPS = [
["Describe the cadence", "Tell Ceptly who checks in and how often, in plain English. It drafts a schedule you publish and adjust anytime."],
["ICs answer in Slack", "Each teammate gets a short, conversational DM. Progress, blockers, and linked Linear, Jira & Monday issues\u2014no forms."],
["Leaders get rollups", "Ask about blockers or morale in chat. Insights are grounded in what your team actually said, with rollups after each window."]];

function HowItWorks() {
  return (
    <section className="section" id="how">
      <div className="container">
        <div className="shead">
          <span className="kicker">How it works</span>
          <h2>Three steps to effortless momentum</h2>
          <p>Set it up once in chat. Your team answers in Slack. You stay in the loop without the overhead.</p>
        </div>
        <div className="steps3">
          {STEPS.map(([t, d], i) =>
          <div className="step" key={t}>
              <div className="num">{i + 1}</div>
              <h3>{t}</h3>
              <p>{d}</p>
            </div>
          )}
        </div>
      </div>
    </section>);

}

/* ---- features 2x2 ---- */
const FEATURES = [
["calendar", "Scheduling in chat", "Describe a cadence in plain English; Ceptly builds a publishable schedule\u2014who answers, how often, and where rollups land."],
["message-square", "Slack check-ins", "On schedule, Ceptly DMs each teammate for a short, conversational standup. Progress, blockers, and linked issues\u2014without forms."],
["sparkles", "Team insights", "Ask about blockers, morale, or check-in history in chat. Answers are grounded in what your team actually said."],
["send", "One-off reach-out", "Fire a single Slack DM to any teammate for a quick follow-up, or broadcast a standup to a whole channel."]];

function Features() {
  return (
    <section className="section" id="features">
      <div className="container">
        <div className="shead">
          <span className="kicker">What Ceptly does</span>
          <h2>Visibility without the overhead</h2>
          <p>Everything a chief of staff would handle&mdash;coordination, follow-up, and grounded answers&mdash;run by an agent.</p>
        </div>
        <div className="feat-grid">
          {FEATURES.map(([ic, t, d]) =>
          <div className="feat" key={t}>
              <div className="ic-box"><Icon name={ic} size={20} /></div>
              <h3>{t}</h3>
              <p>{d}</p>
            </div>
          )}
        </div>
      </div>
    </section>);

}

/* ---- pricing ---- */
const INCLUDED = [
"Slack conversational check-ins on your schedule",
"AI scheduling assistant\u2014set cadence and topics in plain English",
"Team insights chat\u2014ask about blockers, morale, and history",
"One-off Slack reach-out and channel standups",
"Linear, Jira & Monday issue linking",
"Team roster with role-based access"];

function Pricing() {
  return (
    <section className="section pricing" id="pricing">
      <div className="pricing-glow" />
      <div className="container">
        <div className="shead">
          <span className="kicker">Pricing</span>
          <h2>One plan. Per seat. No surprises.</h2>
          <p>Everything you need to organize your org&rsquo;s communication. Try Ceptly free for 10 days.</p>
        </div>
        <div className="plan">
          <div className="pl-eyebrow">Starter</div>
          <div className="price">$20<span>/seat/month</span></div>
          <div className="terms">Billed per teammate seat via Stripe &middot; cancel anytime</div>
          <ul>
            {INCLUDED.map((f) =>
            <li key={f}><Icon name="check" size={17} /><span>{f}</span></li>
            )}
          </ul>
          <a className="btn btn-cta" href="#">Create account <Icon name="arrow-right" size={16} /></a>
        </div>
      </div>
    </section>);

}

/* ---- faq ---- */
const FAQS = [
["Do my teammates need a Ceptly login?", "No. ICs answer right inside Slack DMs\u2014only leaders use the app for rollups and insights, so there&rsquo;s nothing new for your team to learn."],
["How does Ceptly know what to ask?", "You describe the cadence in plain English; Ceptly drafts a schedule and conversational check-ins you review and publish. Adjust anytime."],
["Where do the answers go?", "Into grounded team insights you can query in chat\u2014blockers, morale, history\u2014plus rollups that land in your leadership channel after each window."],
["Which tools does it connect to?", "Slack for check-ins and reach-out, and Linear, Jira & Monday for linked issues, so standups stay tied to real work. More integrations on the way."],
["Is my team&rsquo;s data private?", "Answers are used to ground your team&rsquo;s own insights and rollups\u2014nothing more. Role-based access keeps visibility appropriate for founders, leads, and ICs."]];

function FAQ() {
  const [open, setOpen] = useState(0);
  return (
    <section className="section" id="faq">
      <div className="container">
        <div className="shead">
          <span className="kicker">FAQ</span>
          <h2>Questions, answered</h2>
        </div>
        <div className="faq">
          {FAQS.map(([q, a], i) =>
          <div className={"faq-item" + (open === i ? " open" : "")} key={i}>
              <button className="faq-q" onClick={() => setOpen(open === i ? -1 : i)}>
                <h3 dangerouslySetInnerHTML={{ __html: q }} />
                <Icon name="chevron-down" size={20} />
              </button>
              <div className="faq-a"><p dangerouslySetInnerHTML={{ __html: a }} /></div>
            </div>
          )}
        </div>
      </div>
    </section>);

}

/* ---- final cta ---- */
function FinalCTA() {
  return (
    <section className="final">
      <div className="final-grid" />
      <div className="container final-in">
        <h2>Turn ambitious vision into effortless momentum</h2>
        <p className="sub" style={{ color: "var(--fg2)", maxWidth: 540, margin: 0 }}>
          Schedule your first check-in in minutes. Free for 10 days, no credit card required.
        </p>
        <a className="btn btn-cta" href="#">Create account <Icon name="arrow-right" size={16} /></a>
      </div>
    </section>);

}

/* ---- footer ---- */
function Footer() {
  return (
    <footer className="ft">
      <div className="container">
        <div className="ft-top">
          <div className="ft-brand">
            <Brand />
            <p className="slogan">AI organizing organizations.</p>
            <p>Ceptly&rsquo;s agents handle coordination and visibility for flat teams&mdash;so ICs focus on deep work and leaders stay aligned without the overhead.</p>
          </div>
          <div className="ft-cols">
            <div className="ft-col"><span className="h">Product</span><a href="#how">How it works</a><a href="#features">Features</a><a href="#pricing">Pricing</a><a href="#faq">FAQ</a></div>
            <div className="ft-col"><span className="h">Company</span><a href="#">About</a><a href="#">Careers</a><a href="#">Contact</a></div>
            <div className="ft-col"><span className="h">Legal</span><a href="#">Privacy</a><a href="#">Terms</a></div>
          </div>
        </div>
        <div className="ft-bottom">
          <span className="copy">&copy; 2026 Ceptly Inc. All rights reserved.</span>
          <a href="#" className="copy">Privacy Policy</a>
        </div>
      </div>
    </footer>);

}

Object.assign(window, { Icon, Header, Hero, Showcase, DeployDemo, Integrations, HowItWorks, Features, Pricing, FAQ, FinalCTA, Footer });