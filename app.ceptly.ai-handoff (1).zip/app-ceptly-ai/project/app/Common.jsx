/* global React */
// Ceptly App — shared primitives (Lucide via CDN). Exported to window.
const { useState, useEffect, useRef, useCallback } = React;

// ---- Icon -------------------------------------------------------------
function Icon({ name, size = 16, className = "", color, strokeWidth = 2 }) {
  const ref = useRef(null);
  useEffect(() => {
    const host = ref.current;
    if (!host || !window.lucide) return;
    host.innerHTML = "";
    const i = document.createElement("i");
    i.setAttribute("data-lucide", name);
    i.setAttribute("width", size);
    i.setAttribute("height", size);
    i.setAttribute("stroke-width", strokeWidth);
    if (color) i.setAttribute("color", color);
    host.appendChild(i);
    window.lucide.createIcons({ root: host });
  }, [name, size, color, strokeWidth]);
  return (
    <span ref={ref} className={"cep-icon " + className}
      style={{ width: size, height: size }} />
  );
}

// ---- Button -----------------------------------------------------------
function Button({ variant = "default", size = "default", pill = false, className = "", children, ...props }) {
  const cls = [
    "cep-btn", `cep-btn-${variant}`,
    size !== "default" ? `cep-btn-${size}` : "",
    pill ? "cep-btn-pill" : "",
    className,
  ].filter(Boolean).join(" ");
  return <button className={cls} {...props}>{children}</button>;
}

// ---- Badge ------------------------------------------------------------
function Badge({ variant = "default", className = "", style, children }) {
  return <span className={`cep-badge cep-badge-${variant} ${className}`} style={style}>{children}</span>;
}

// ---- Avatar -----------------------------------------------------------
function Avatar({ initials, className = "", spark = false, logo = false, theme = "dark" }) {
  return (
    <span className={`cep-avatar ${spark ? "cep-avatar-spark" : ""} ${logo ? "cep-avatar-logo" : ""} ${className}`}>
      {logo ? <img src={theme === "light" ? "assets/parallax-light.png" : "assets/parallax-dark.png"} alt="Ceptly" />
        : spark ? <Icon name="sparkles" size={13} />
          : initials}
    </span>
  );
}

// ---- Field (label + input, optional leading icon) ---------------------
function Field({ label, hint, error, icon, children, id }) {
  return (
    <div>
      {label ? <label className="cep-label" htmlFor={id}>{label}</label> : null}
      {icon ? (
        <div className="cep-input-wrap">
          <span className="cep-input-icon"><Icon name={icon} size={16} /></span>
          {children}
        </div>
      ) : children}
      {error ? <p className="cep-field-err">{error}</p> : hint ? <p className="cep-field-hint">{hint}</p> : null}
    </div>
  );
}

// ---- Alert ------------------------------------------------------------
function Alert({ variant = "default", icon, children }) {
  return (
    <div className={`cep-alert cep-alert-${variant}`}>
      {icon ? <Icon name={icon} size={16} /> : null}
      <div>{children}</div>
    </div>
  );
}

// ---- Google glyph -----------------------------------------------------
function GoogleIcon() {
  return (
    <svg className="cep-gicon" viewBox="0 0 24 24" aria-hidden="true">
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"/>
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
    </svg>
  );
}

// ---- useClickOutside --------------------------------------------------
function useClickOutside(onOut) {
  const ref = useRef(null);
  useEffect(() => {
    function h(e) { if (ref.current && !ref.current.contains(e.target)) onOut(); }
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, [onOut]);
  return ref;
}

// ---- Pager -------------------------------------------------------------
function Pager({ page, pages, onChange }) {
  if (pages <= 1) return null;
  const nums = [];
  for (let i = 0; i < pages; i++) nums.push(i);
  return (
    <div className="cep-pager">
      <button className="cep-pager-btn" disabled={page === 0} onClick={() => onChange(page - 1)} aria-label="Previous">
        <Icon name="chevron-left" size={15} />
      </button>
      {nums.map((i) => (
        <button key={i} className={"cep-pager-btn" + (i === page ? " active" : "")} onClick={() => onChange(i)}>{i + 1}</button>
      ))}
      <button className="cep-pager-btn" disabled={page === pages - 1} onClick={() => onChange(page + 1)} aria-label="Next">
        <Icon name="chevron-right" size={15} />
      </button>
    </div>
  );
}

Object.assign(window, { Icon, Button, Badge, Avatar, Field, Alert, GoogleIcon, useClickOutside, Pager });
