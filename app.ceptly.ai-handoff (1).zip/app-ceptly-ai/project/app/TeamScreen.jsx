/* global React, Icon, Button, Badge, useClickOutside */
// Ceptly App — Team roster (table + import + invite)

const { useState: useTeamState } = React;

const linearLogo = (theme) => theme === "light" ? "assets/integrations/linear-dark.png" : "assets/integrations/linear-light.png";
const APP_META = (theme) => ({
  slack: { label: "Slack", logo: "assets/integrations/slack.png" },
  linear: { label: "Linear", logo: linearLogo(theme) },
  jira: { label: "Jira", logo: "assets/integrations/Jira_icon.png" },
  monday: { label: "Monday", logo: "assets/integrations/monday.png" },
});

const TZ_OPTIONS = [
  "US/Pacific", "US/Mountain", "US/Central", "US/Eastern",
  "Europe/London", "Europe/Berlin", "Asia/Kolkata", "Asia/Tokyo", "Australia/Sydney",
];
const LANG_OPTIONS = ["English", "Spanish", "French", "German", "Portuguese", "Hindi", "Japanese"];

const INITIAL = [
  { name: "Trey Chen", email: "trey@acme.com", tz: "US/Pacific", lang: "English", apps: ["slack", "linear"] },
  { name: "Mara Olsen", email: "mara@acme.com", tz: "US/Eastern", lang: "English", apps: ["slack", "linear", "jira"] },
  { name: "Devin Park", email: "devin@acme.com", tz: "Europe/London", lang: "English", apps: ["slack"] },
  { name: "Priya Nair", email: "priya@acme.com", tz: "Asia/Kolkata", lang: "English", apps: ["slack", "monday"] },
  { name: "Sam Rivera", email: "sam@acme.com", tz: "US/Central", lang: "Spanish", apps: ["slack", "linear"] },
  { name: "Ivy Lawson", email: "ivy@acme.com", tz: "US/Pacific", lang: "English", apps: ["slack", "monday"] },
  { name: "Noah Whitfield", email: "noah@acme.com", tz: "US/Mountain", lang: "English", apps: ["slack", "linear"] },
  { name: "Lena Schmidt", email: "lena@acme.com", tz: "Europe/Berlin", lang: "German", apps: ["slack", "jira"] },
  { name: "Marco Bianchi", email: "marco@acme.com", tz: "Europe/Berlin", lang: "English", apps: ["slack"] },
  { name: "Yuki Tanaka", email: "yuki@acme.com", tz: "Asia/Tokyo", lang: "Japanese", apps: ["slack", "linear"] },
  { name: "Aïsha Diallo", email: "aisha@acme.com", tz: "Europe/London", lang: "French", apps: ["slack", "monday"] },
  { name: "Carlos Mendez", email: "carlos@acme.com", tz: "US/Central", lang: "Spanish", apps: ["slack", "jira"] },
  { name: "Hannah Park", email: "hannah@acme.com", tz: "US/Eastern", lang: "English", apps: ["slack", "linear", "monday"] },
  { name: "Omar Haddad", email: "omar@acme.com", tz: "Asia/Kolkata", lang: "English", apps: ["slack"] },
  { name: "Sofia Rossi", email: "sofia@acme.com", tz: "Europe/Berlin", lang: "English", apps: ["slack", "linear"] },
  { name: "Liam O'Brien", email: "liam@acme.com", tz: "Europe/London", lang: "English", apps: ["slack", "jira"] },
  { name: "Grace Kim", email: "grace@acme.com", tz: "Australia/Sydney", lang: "English", apps: ["slack", "linear"] },
  { name: "Diego Santos", email: "diego@acme.com", tz: "US/Eastern", lang: "Portuguese", apps: ["slack", "monday"] },
  { name: "Fatima Khan", email: "fatima@acme.com", tz: "Asia/Kolkata", lang: "Hindi", apps: ["slack", "jira"] },
  { name: "Erik Johansson", email: "erik@acme.com", tz: "Europe/Berlin", lang: "English", apps: ["slack"] },
  { name: "Nina Petrova", email: "nina@acme.com", tz: "Europe/Berlin", lang: "English", apps: ["slack", "linear"] },
  { name: "Tomás Alvarez", email: "tomas@acme.com", tz: "US/Pacific", lang: "Spanish", apps: ["slack", "linear", "jira"] },
  { name: "Chloe Dubois", email: "chloe@acme.com", tz: "Europe/London", lang: "French", apps: ["slack", "monday"] },
  { name: "Ravi Menon", email: "ravi@acme.com", tz: "Asia/Kolkata", lang: "English", apps: ["slack"] },
  { name: "Bella Nguyen", email: "bella@acme.com", tz: "Australia/Sydney", lang: "English", apps: ["slack", "linear"] },
  { name: "Jonas Weber", email: "jonas@acme.com", tz: "Europe/Berlin", lang: "German", apps: ["slack", "jira"] },
  { name: "Maya Goldberg", email: "maya@acme.com", tz: "US/Eastern", lang: "English", apps: ["slack", "linear", "monday"] },
  { name: "Andre Costa", email: "andre@acme.com", tz: "US/Central", lang: "Portuguese", apps: ["slack"] },
];

function RowMenu({ onRemove, onEdit }) {
  const [open, setOpen] = useTeamState(false);
  const ref = useClickOutside(() => setOpen(false));
  return (
    <span className="cep-menu-wrap" ref={ref}>
      <Button variant="ghost" size="icon-sm" aria-label="Actions" onClick={() => setOpen((o) => !o)}><Icon name="ellipsis" size={16} /></Button>
      {open ? (
        <div className="cep-menu cep-fade-in" style={{ width: 170 }}>
          <button className="cep-menu-item"><Icon name="message-square" size={14} /> Message in Slack</button>
          <button className="cep-menu-item" onClick={() => { setOpen(false); onEdit(); }}><Icon name="pencil" size={14} /> Edit details</button>
          <div className="cep-menu-sep" />
          <button className="cep-menu-item" style={{ color: "var(--destructive)" }} onClick={() => { setOpen(false); onRemove(); }}>
            <Icon name="trash-2" size={14} /> Remove
          </button>
        </div>
      ) : null}
    </span>
  );
}

const ALL_APPS = ["slack", "linear", "jira", "monday"];

function EditMemberDialog({ member, theme, onSave, onClose }) {
  const [form, setForm] = useTeamState(member);
  const apps = APP_META(theme);
  const set = (patch) => setForm((f) => ({ ...f, ...patch }));
  const toggleApp = (a) => set({ apps: form.apps.includes(a) ? form.apps.filter((x) => x !== a) : [...form.apps, a] });
  return (
    <div className="cep-overlay" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="cep-modal cep-fade">
        <div className="cep-modal-head">
          <div>
            <div className="cep-modal-title">Edit member</div>
            <div className="cep-modal-sub">Update profile, timezone, language, and connected apps.</div>
          </div>
          <button className="cep-modal-x" aria-label="Close" onClick={onClose}><Icon name="x" size={18} /></button>
        </div>
        <div className="cep-modal-body">
          <Field label="Full name">
            <input className="cep-input" value={form.name} onChange={(e) => set({ name: e.target.value })} />
          </Field>
          <Field label="Email" hint="Must match a Slack account in your connected team.">
            <input className="cep-input" type="email" value={form.email} onChange={(e) => set({ email: e.target.value })} />
          </Field>
          <Field label="Secondary email" hint="Optional — used to match Linear, Jira, or Monday.com if it differs from Slack.">
            <input className="cep-input" type="email" value={form.email2 || ""} placeholder="name@othercompany.com" onChange={(e) => set({ email2: e.target.value })} />
          </Field>
          <div className="cep-field-grid">
            <Field label="Timezone">
              <select className="cep-select cep-select-block" value={form.tz} onChange={(e) => set({ tz: e.target.value })}>
                {TZ_OPTIONS.includes(form.tz) ? null : <option value={form.tz}>{form.tz}</option>}
                {TZ_OPTIONS.map((tz) => <option key={tz} value={tz}>{tz}</option>)}
              </select>
            </Field>
            <Field label="Language">
              <select className="cep-select cep-select-block" value={form.lang} onChange={(e) => set({ lang: e.target.value })}>
                {LANG_OPTIONS.includes(form.lang) ? null : <option value={form.lang}>{form.lang}</option>}
                {LANG_OPTIONS.map((l) => <option key={l} value={l}>{l}</option>)}
              </select>
            </Field>
          </div>
          <div>
            <label className="cep-label">Connected apps</label>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
              {ALL_APPS.map((a) => {
                const on = form.apps.includes(a);
                return (
                  <button type="button" key={a} onClick={() => toggleApp(a)}
                    className={"cep-chip" + (on ? " sel-app" : "")}
                    style={on ? { borderColor: "var(--green-ink)", background: "var(--green-wash)" } : {}}>
                    <img src={apps[a].logo} alt="" style={{ width: 14, height: 14 }} /> {apps[a].label}
                    {on ? <Icon name="check" size={12} /> : null}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
        <div className="cep-modal-foot">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button variant="default" onClick={() => onSave(form)}>Save changes</Button>
        </div>
      </div>
    </div>
  );
}

function TeamScreen({ theme = "dark" }) {
  const [members, setMembers] = useTeamState(INITIAL);
  const [email, setEmail] = useTeamState("");
  const [editing, setEditing] = useTeamState(null);
  const apps = APP_META(theme);

  function updateMember(email, patch) {
    setMembers((cur) => cur.map((m) => m.email === email ? { ...m, ...patch } : m));
  }

  function saveMember(original, form) {
    setMembers((cur) => cur.map((m) => m.email === original.email ? form : m));
    setEditing(null);
  }

  function add(e) {
    e.preventDefault();
    const v = email.trim();
    if (!v) return;
    const name = v.split("@")[0].replace(/\./g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
    setMembers((m) => [...m, { name, email: v, tz: "US/Pacific", lang: "English", apps: ["slack"] }]);
    setEmail("");
  }

  return (
    <div className="cep-page">
      <div className="cep-page-head">
        <div className="cep-page-title">Team</div>
        <div className="cep-page-sub">Manage who receives check-ins. Imported from Slack and Linear.</div>
      </div>

      <div className="cep-toolbar">
        <Button variant="outline"><img src="assets/integrations/slack.png" alt="" style={{ width: 15, height: 15 }} /> Sync with Slack</Button>
        <Button variant="outline"><img src={linearLogo(theme)} alt="" style={{ width: 15, height: 15 }} /> Sync with Linear</Button>
        <Button variant="outline"><img src="assets/integrations/Jira_icon.png" alt="" style={{ width: 15, height: 15 }} /> Sync with Jira</Button>
        <Button variant="outline"><img src="assets/integrations/monday.png" alt="" style={{ width: 15, height: 15 }} /> Sync with Monday</Button>
        <span className="cep-toolbar-spacer" />
        <Badge variant="outline">{members.length} members</Badge>
      </div>

      <div className="cep-table-wrap">
        <table className="cep-table">
          <thead>
            <tr><th>Name</th><th>Email</th><th>Timezone</th><th>Language</th><th>Apps</th><th></th></tr>
          </thead>
          <tbody>
            {members.map((m) => (
              <tr key={m.email}>
                <td>
                  <span className="name">
                    <span className="cep-avatar cep-avatar-sm">{m.name.split(" ").map((p) => p[0]).join("").slice(0, 2)}</span>
                    {m.name}
                  </span>
                </td>
                <td className="muted">{m.email}</td>
                <td className="muted">{m.tz}</td>
                <td className="muted">{m.lang}</td>
                <td>
                  <span className="cep-apps">
                    {m.apps.map((a) => <img key={a} className="cep-applogo" src={apps[a].logo} alt={apps[a].label} title={apps[a].label} />)}
                  </span>
                </td>
                <td style={{ textAlign: "right" }}>
                  <RowMenu onEdit={() => setEditing(m)} onRemove={() => setMembers((cur) => cur.filter((x) => x.email !== m.email))} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <form onSubmit={add}>
        <div className="cep-add-row">
          <div className="cep-input-wrap" style={{ flex: 1 }}>
            <span className="cep-input-icon"><Icon name="mail" size={16} /></span>
            <input className="cep-input" type="email" placeholder="teammate@company.com" value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <Button type="submit" variant="default">Add member</Button>
        </div>
        <p className="cep-field-hint">Must match a Slack account in your connected team.</p>
      </form>

      {editing ? (
        <EditMemberDialog key={editing.email} member={editing} theme={theme}
          onSave={(form) => saveMember(editing, form)} onClose={() => setEditing(null)} />
      ) : null}
    </div>
  );
}

window.TeamScreen = TeamScreen;
