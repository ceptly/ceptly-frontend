/* global React, Icon, Avatar, Button, useClickOutside */
// Ceptly App — top-bar account header + avatar dropdown

function AccountHeader({ active, onNavigate, onSignOut, workspaceName = "Acme Team", user, theme = "dark", attentionCount = 2 }) {
  const [open, setOpen] = React.useState(false);
  const ref = useClickOutside(() => setOpen(false));
  const items = [
    { id: "chat", label: "Chat" },
    { id: "activity", label: "Activity", badge: attentionCount },
    { id: "agents", label: "Agents" },
    { id: "team", label: "Team", hideMobile: true },
    { id: "settings", label: "Settings", hideMobile: true },
  ];
  function go(id, sub) { setOpen(false); onNavigate(id, sub); }
  return (
    <header className="cep-header">
      <div className="cep-header-inner">
        <div className="cep-header-left">
          <span className="cep-logo" onClick={() => onNavigate("chat")} title="Ceptly">
            <img src={theme === "light" ? "assets/parallax-light.png" : "assets/parallax-dark.png"} alt="Ceptly" />
          </span>
          <nav className="cep-nav">
            <button className="cep-nav-item cep-nav-ws" onClick={() => onNavigate("settings")}>{workspaceName}</button>
            {items.map((it) => (
              <button key={it.id}
                className={"cep-nav-item" + (active === it.id ? " active" : "") + (it.hideMobile ? " cep-nav-hide-mobile" : "")}
                onClick={() => onNavigate(it.id)}>
                {it.label}
                {it.badge && active !== it.id ? (
                  <span className="cep-nav-badge">{it.badge > 9 ? "9+" : it.badge}</span>
                ) : null}
              </button>
            ))}
          </nav>
        </div>

        <div className="cep-menu-wrap" ref={ref}>
          <button className="cep-avatar" onClick={() => setOpen((o) => !o)} aria-label="Account">
            {user.initials}
          </button>
          {open ? (
            <div className="cep-menu cep-fade-in">
              <div className="cep-menu-label">
                <div className="cep-menu-name">{user.name}</div>
                <div className="cep-menu-mail">{user.email}</div>
              </div>

              {/* Mobile-only: nav targets removed from the header */}
              <div className="cep-menu-sep cep-menu-mobile-only" />
              <button className="cep-menu-item cep-menu-mobile-only" onClick={() => go("team")}>
                <Icon name="users" size={15} /> Team
              </button>

              <div className="cep-menu-sep" />
              <button className="cep-menu-item" onClick={() => go("settings")}>
                <Icon name="settings-2" size={15} /> Team settings
              </button>
              <button className="cep-menu-item" onClick={() => go("settings", "account")}>
                <Icon name="user" size={15} /> Account
              </button>
              <button className="cep-menu-item cep-menu-mobile-only" onClick={() => go("settings", "integrations")}>
                <Icon name="plug" size={15} /> Integrations
              </button>
              <button className="cep-menu-item cep-menu-mobile-only" onClick={() => go("settings", "standups")}>
                <Icon name="hash" size={15} /> Channel standups
              </button>
              <button className="cep-menu-item cep-menu-mobile-only" onClick={() => go("settings", "billing")}>
                <Icon name="credit-card" size={15} /> Billing
              </button>

              <div className="cep-menu-sep" />
              <button className="cep-menu-item" onClick={() => { setOpen(false); onSignOut(); }}>
                <Icon name="log-out" size={15} /> Sign out
              </button>
            </div>
          ) : null}
        </div>
      </div>
    </header>
  );
}

window.AccountHeader = AccountHeader;
