/* global React, Icon, Button, Badge, useClickOutside */
// Ceptly App — Activity (standup rollups list + detail with past-session picker)

const { useState: useActState } = React;

const STANDUPS = [
  {
    id: "eng", name: "Daily Engineering Standup", channel: "#eng-standup", style: "Sequential", attention: true,
    sessions: [
      {
        date: "Today · Tue, May 27, 9:00 AM", responded: 3, expected: 5,
        summary: "Two blockers raised on the billing migration; rest on track for the Friday release.",
        members: [
          { name: "Trey Chen", status: "responded", note: "Blocked on the dashboard empty-state API — waiting on the schema from Mara." },
          { name: "Mara Olsen", status: "responded", note: "Shipping the schema today. Reviewing Sam's PR after lunch." },
          { name: "Sam Rivera", status: "responded", note: "Billing migration 80% done. One edge case on proration left." },
          { name: "Devin Park", status: "waiting", note: null },
          { name: "Priya Nair", status: "waiting", note: null },
        ],
      },
      {
        date: "Mon, May 26, 9:00 AM", responded: 5, expected: 5,
        summary: "All clear. Billing migration entered QA and the dashboard API was merged to main.",
        members: [
          { name: "Trey Chen", status: "responded", note: "Wired up the empty states against the new API. Looks good." },
          { name: "Mara Olsen", status: "responded", note: "Dashboard API merged. Moving to the export endpoint next." },
          { name: "Sam Rivera", status: "responded", note: "Billing migration in QA. No blockers." },
          { name: "Devin Park", status: "responded", note: "Finished the retry logic. Picking up the proration edge case." },
          { name: "Priya Nair", status: "responded", note: "Closed three flaky tests. Pipeline is green again." },
        ],
      },
      {
        date: "Fri, May 23, 9:00 AM", responded: 4, expected: 5,
        summary: "Dashboard API design finalized. Priya out sick; everyone else on track.",
        members: [
          { name: "Trey Chen", status: "responded", note: "Reviewed the API design. Ready to build once it lands." },
          { name: "Mara Olsen", status: "responded", note: "Locked the schema. Starting implementation today." },
          { name: "Sam Rivera", status: "responded", note: "Migration script drafted. Needs a dry run on staging." },
          { name: "Devin Park", status: "responded", note: "Paired with Sam on the script. No blockers." },
          { name: "Priya Nair", status: "waiting", note: null },
        ],
      },
    ],
  },
  {
    id: "design", name: "Design Weekly Check-in", channel: "#design", style: "Broadcast", attention: false,
    sessions: [
      {
        date: "Mon, May 26, 10:00 AM", responded: 2, expected: 2,
        summary: "Empty-state explorations shared. Trey flagged a dependency on the dashboard API.",
        members: [
          { name: "Trey Chen", status: "responded", note: "Posted three empty-state directions. Need the dashboard API to wire them up." },
          { name: "Ivy Lawson", status: "responded", note: "Finalized the icon set. Handing off to eng this week." },
        ],
      },
      {
        date: "Mon, May 19, 10:00 AM", responded: 2, expected: 2,
        summary: "Icon set review wrapped; both designers aligned on the new square-corner language.",
        members: [
          { name: "Trey Chen", status: "responded", note: "Refined the proposal-card layout. Square corners feel sharper." },
          { name: "Ivy Lawson", status: "responded", note: "Drafted the icon set in the Lucide style at 2px stroke." },
        ],
      },
    ],
  },
  {
    id: "founders", name: "Founders Pulse", channel: "DM · 2 leads", style: "Sequential", attention: false,
    sessions: [
      {
        date: "Fri, May 23, 4:00 PM", responded: 2, expected: 2,
        summary: "Hiring pipeline healthy; runway concerns parked for next board prep.",
        members: [
          { name: "Jordan Avery", status: "responded", note: "Two strong eng candidates in final rounds. Closing this week." },
          { name: "Riya Shah", status: "responded", note: "Runway at 14 months. Will model scenarios before the board sync." },
        ],
      },
    ],
  },
  {
    id: "support", name: "Support Triage", channel: "#support", style: "Broadcast", attention: true,
    sessions: [
      { date: "Today · Tue, May 27, 8:30 AM", responded: 1, expected: 6, summary: null, members: [
        { name: "Devin Park", status: "responded", note: "Cleared the overnight queue. Two escalations pending eng input." },
      ] },
    ],
  },
];

function SessionPicker({ sessions, sel, onSelect }) {
  const [open, setOpen] = useActState(false);
  const ref = useClickOutside(() => setOpen(false));
  return (
    <div className="cep-menu-wrap" ref={ref}>
      <Button variant="outline" size="sm" onClick={() => setOpen((o) => !o)}>
        <Icon name="calendar" size={14} /> {sessions[sel].date}
        <Icon name="chevron-down" size={14} />
      </Button>
      {open ? (
        <div className="cep-menu cep-fade-in" style={{ width: 268 }}>
          <div className="cep-menu-label" style={{ paddingBottom: 4 }}>
            <div className="cep-menu-mail" style={{ textTransform: "uppercase", letterSpacing: ".05em", fontWeight: 600 }}>Past sessions</div>
          </div>
          {sessions.map((s, i) => (
            <button key={i} className="cep-menu-item" style={{ alignItems: "flex-start" }} onClick={() => { onSelect(i); setOpen(false); }}>
              <Icon name={i === sel ? "check" : "calendar"} size={14} />
              <span>
                <span style={{ display: "block", fontWeight: i === sel ? 600 : 500 }}>{s.date}</span>
                <span style={{ display: "block", fontSize: 11.5, color: "var(--fg2)", marginTop: 2 }}>{s.responded}/{s.expected} responded</span>
              </span>
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}

function StandupDetail({ s, onBack }) {
  const [sel, setSel] = useActState(0);
  const ses = s.sessions[sel];
  const pct = ses.expected ? Math.round((ses.responded / ses.expected) * 100) : 0;
  return (
    <div className="cep-page cep-page-narrow cep-fade">
      <button className="cep-back" onClick={onBack}><Icon name="arrow-left" size={15} /> Activity</button>
      <div className="cep-page-head" style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 16, flexWrap: "wrap" }}>
        <div>
          <div className="cep-page-title">{s.name}</div>
          <div className="cep-page-sub">{s.channel} · {s.style}</div>
        </div>
        <SessionPicker sessions={s.sessions} sel={sel} onSelect={setSel} />
      </div>

      <div key={sel} className="cep-fade-in">
        <div className="cep-stat-grid" style={{ marginBottom: 28 }}>
          <div className="cep-stat"><div className="cep-stat-val">{ses.responded}/{ses.expected}</div><div className="cep-stat-label">Responded</div></div>
          <div className="cep-stat"><div className="cep-stat-val">{pct}%</div><div className="cep-stat-label">Completion</div></div>
          <div className="cep-stat"><div className="cep-stat-val">{ses.expected - ses.responded}</div><div className="cep-stat-label">Still waiting</div></div>
        </div>

        {ses.summary ? (
          <div className="cep-section">
            <div className="cep-section-title"><Icon name="sparkles" size={15} color="#B1FFA5" /> Rollup summary</div>
            <div className="cep-card" style={{ padding: 18 }}><p style={{ margin: 0, fontSize: 14, lineHeight: 1.6 }}>{ses.summary}</p></div>
          </div>
        ) : null}

        <div className="cep-section">
          <div className="cep-section-title"><Icon name="users" size={15} /> Responses</div>
          {ses.members.length ? (
            <div className="cep-list-card">
              {ses.members.map((m) => (
                <div className="cep-list-row" key={m.name} style={{ alignItems: "flex-start" }}>
                  <span className="cep-avatar cep-avatar-sm">{m.name.split(" ").map((p) => p[0]).join("")}</span>
                  <div className="cep-list-main">
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <span className="cep-list-name">{m.name}</span>
                      {m.status === "responded"
                        ? <Badge variant="green"><Icon name="check" size={11} /> Responded</Badge>
                        : <Badge variant="secondary">Waiting</Badge>}
                    </div>
                    {m.note ? <div className="cep-list-desc" style={{ marginTop: 6 }}>{m.note}</div>
                      : <div className="cep-list-desc" style={{ marginTop: 6, fontStyle: "italic" }}>No reply yet.</div>}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="cep-card" style={{ padding: 20 }}>
              <p className="cep-card-empty" style={{ marginTop: 0 }}>No individual responses to show for this session yet.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StandupCard({ s, onOpen }) {
  const ses = s.sessions[0];
  const pct = ses.expected ? Math.round((ses.responded / ses.expected) * 100) : 0;
  const full = ses.responded === ses.expected;
  return (
    <div className="cep-card cep-card-link" onClick={() => onOpen(s)}>
      <div className="cep-card-top">
        <div>
          <div className="cep-card-title">{s.name}</div>
          <div className="cep-card-desc">{s.channel} · {s.style}</div>
        </div>
        {s.attention ? <Badge variant="attention">Needs attention</Badge> : full ? <Badge variant="green"><Icon name="check" size={11} /> Complete</Badge> : null}
      </div>
      <div className="cep-meta">
        <span className="muted">Latest · {ses.date.replace(/^Today · /, "Today · ")}</span>
        <span style={{ fontWeight: 600 }}>{ses.responded}/{ses.expected} responded</span>
      </div>
      <div className="cep-track"><div className={"cep-fill" + (full ? " full" : "")} style={{ width: pct + "%" }} /></div>
      {ses.summary ? <p className="cep-card-sum">{ses.summary}</p>
        : <p className="cep-card-empty">No standup sessions yet. Results appear after the schedule fires.</p>}
      {s.sessions.length > 1 ? (
        <div style={{ marginTop: 12, fontSize: 12, color: "var(--fg2)", display: "flex", alignItems: "center", gap: 6 }}>
          <Icon name="history" size={13} /> {s.sessions.length} past sessions
        </div>
      ) : null}
    </div>
  );
}

// ---- Roster-match warnings ----
const WARNINGS = [
  {
    id: "w1", name: "Michael Ehmke", email: "michael@ehmke.ai",
    title: "Michael Ehmke · no Linear, Jira or Monday.com account matches michael@ehmke.ai",
    desc: "Use the same email in Slack and Linear, Jira or Monday.com. Update the roster email on Team or fix the email in your issue tracker.",
  },
  {
    id: "w2", name: "timothycarpp", email: "timothycarpp@gmail.com",
    title: "timothycarpp · no Linear, Jira, Monday.com or ClickUp account matches timothycarpp@gmail.com",
    desc: "Use the same email in Slack and Linear, Jira, Monday.com or ClickUp. Update the roster email on Team or fix the email in your issue tracker.",
  },
];

// ---- Recent reach-outs ----
const REACHOUTS = [
  {
    id: "r1", intent: "Gather information", title: "Task check-in", status: "completed",
    recipient: { name: "Michael", email: "michael@ceptly.com" }, topic: "task status check-in",
    date: "May 26, 2026, 5:09 PM",
    promptPreview: "## Opening message prompt\nYour team lead asked for a quick update on your in-progress Linear issues.\n…",
    agentPrompt: "## Role\nYou are Ceptly, reaching out to Michael on behalf of their team lead.\n\n## Goal\nGather information — confirm the status of Michael's in-progress Linear issues and surface any blockers.\n\n## Context\n• CHE-1 — Define landing site goals and success metrics (in progress)\n\n## Style\nFriendly, brief, one question at a time. Stop once the picture is clear.",
    conversation: [
      { role: "ai", time: "May 26, 2026, 5:09 PM", text: "Hi Michael! Your team lead asked for a quick update — you're in progress on these Linear issues:\n• CHE-1 — Define landing site goals and success metrics\n\nAny updates or blockers on these? Anything else you're picking up today?" },
      { role: "user", time: "May 26, 2026, 5:09 PM", text: "no update still in progress" },
      { role: "ai", time: "May 26, 2026, 5:09 PM", text: "Understood, thanks for the update, Michael. I'll leave CHE-1 as in progress. Let me know if anything changes!" },
    ],
  },
  {
    id: "r2", intent: "Teach / inform", title: "Welcome message", status: "in progress",
    recipient: { name: "Mykyta Krumalenko", email: "mykyta@acme.com" }, topic: "welcome new teammate",
    date: "May 28, 9:45 PM",
    promptPreview: "## Opening message prompt\nYour team lead asked you to teach or inform Mykyta Krumalenko about something.\n…",
    agentPrompt: "## Role\nYou are Ceptly, sending a welcome message to Mykyta Krumalenko.\n\n## Goal\nTeach / inform — share the onboarding basics and where to find help.\n\n## Style\nWarm, concise, no jargon.",
    conversation: [
      { role: "ai", time: "May 28, 9:45 PM", text: "Welcome to the team, Mykyta! I'm Ceptly — I'll check in now and then so your leads stay in the loop without status meetings. Anything you need to get started?" },
    ],
  },
  {
    id: "r3", intent: "Teach / inform", title: "birthday greeting", status: "completed",
    recipient: { name: "Michael", email: "michael@ceptly.com" }, topic: "send a birthday greeting",
    date: "May 27, 10:15 PM",
    promptPreview: "## Opening message prompt\nYour team lead asked you to teach or inform Michael about something.\n…",
    agentPrompt: "## Role\nYou are Ceptly, sending Michael a birthday greeting on behalf of the team.\n\n## Style\nCheerful and short.",
    conversation: [
      { role: "ai", time: "May 27, 10:15 PM", text: "Happy birthday, Michael! The whole team's wishing you a great one. Take it easy today." },
      { role: "user", time: "May 27, 10:16 PM", text: "haha thanks!" },
    ],
  },
  {
    id: "r4", intent: "Teach / inform", title: "Birthday wish", status: "abandoned",
    recipient: { name: "Michael", email: "michael@ceptly.com" }, topic: "birthday wish",
    date: "May 27, 10:05 PM",
    promptPreview: "## Opening message prompt\nYour team lead asked you to teach or inform Michael about something.\n…",
    agentPrompt: "## Role\nYou are Ceptly, sending Michael a birthday wish.\n\n## Note\nSuperseded by a later reach-out and abandoned.",
    conversation: [],
  },
  {
    id: "r5", intent: "Gather information", title: "Blocker follow-up", status: "completed",
    recipient: { name: "Trey Chen", email: "trey@acme.com" }, topic: "dashboard empty-state blocker",
    date: "May 27, 9:20 AM",
    promptPreview: "## Opening message prompt\nFollow up with Trey on his dashboard empty-state blocker until it's clear.\n…",
    agentPrompt: "## Role\nYou are Ceptly, following up with Trey about a blocker.\n\n## Goal\nGather information — understand what's blocking the dashboard empty states and who owns the dependency.",
    conversation: [
      { role: "ai", time: "May 27, 9:20 AM", text: "Hey Trey — your lead wanted a quick read on the dashboard empty-state blocker. What's holding it up right now?" },
      { role: "user", time: "May 27, 9:22 AM", text: "waiting on the schema from Mara, should be unblocked today" },
      { role: "ai", time: "May 27, 9:22 AM", text: "Got it — blocked on Mara's schema, expected to clear today. I'll note that for your lead." },
    ],
  },
  {
    id: "r6", intent: "Teach / inform", title: "Policy update", status: "completed",
    recipient: { name: "Priya Nair", email: "priya@acme.com" }, topic: "new on-call rotation",
    date: "May 26, 4:40 PM",
    promptPreview: "## Opening message prompt\nLet Priya know about the new on-call rotation starting next week.\n…",
    agentPrompt: "## Role\nYou are Ceptly, informing Priya about an on-call change.\n\n## Style\nClear and factual.",
    conversation: [
      { role: "ai", time: "May 26, 4:40 PM", text: "Quick heads up, Priya — the new on-call rotation starts Monday. You're on for the second week. The schedule's pinned in #eng-standup." },
      { role: "user", time: "May 26, 4:43 PM", text: "noted, thanks" },
    ],
  },
  {
    id: "r7", intent: "Gather information", title: "Sprint retro pulse", status: "in progress",
    recipient: { name: "Devin Park", email: "devin@acme.com" }, topic: "sprint retro sentiment",
    date: "May 26, 2:10 PM",
    promptPreview: "## Opening message prompt\nAsk Devin for a one-line pulse on how the sprint went.\n…",
    agentPrompt: "## Role\nYou are Ceptly, collecting retro sentiment.\n\n## Goal\nGather information — a quick read on what went well and what didn't.",
    conversation: [
      { role: "ai", time: "May 26, 2:10 PM", text: "Hi Devin — how did this sprint feel to you? One line on what went well and one on what didn't is plenty." },
    ],
  },
  {
    id: "r8", intent: "Teach / inform", title: "Welcome message", status: "completed",
    recipient: { name: "Sam Rivera", email: "sam@acme.com" }, topic: "welcome new teammate",
    date: "May 24, 11:00 AM",
    promptPreview: "## Opening message prompt\nYour team lead asked you to teach or inform Sam Rivera about something.\n…",
    agentPrompt: "## Role\nYou are Ceptly, welcoming Sam Rivera.\n\n## Style\nWarm and brief.",
    conversation: [
      { role: "ai", time: "May 24, 11:00 AM", text: "Welcome aboard, Sam! I'll check in occasionally so your leads stay in the loop without meetings. Reach out anytime." },
      { role: "user", time: "May 24, 11:05 AM", text: "thanks, excited to be here" },
    ],
  },
];

const STATUS_BADGE = {
  "completed": { variant: "green", icon: "check", label: "completed" },
  "in progress": { variant: "secondary", icon: null, label: "in progress" },
  "abandoned": { variant: "outline", icon: null, label: "abandoned" },
};

function StatusBadge({ status }) {
  const b = STATUS_BADGE[status] || STATUS_BADGE["in progress"];
  return <Badge variant={b.variant}>{b.icon ? <Icon name={b.icon} size={11} /> : null}{b.label}</Badge>;
}

// render text, turning ISSUE-123 codes into links
function withIssues(text) {
  const parts = text.split(/\b([A-Z]{2,4}-\d+)\b/g);
  return parts.map((p, i) =>
    /^[A-Z]{2,4}-\d+$/.test(p)
      ? <a key={i} href="#" className="cep-issue-link" onClick={(e) => e.preventDefault()}>{p}</a>
      : <React.Fragment key={i}>{p}</React.Fragment>
  );
}

function Pager({ page, pages, onChange }) {
  if (pages <= 1) return null;
  return (
    <div className="cep-pager">
      <button className="cep-pager-btn" disabled={page === 0} onClick={() => onChange(page - 1)} aria-label="Previous">
        <Icon name="chevron-left" size={15} />
      </button>
      {Array.from({ length: pages }).map((_, i) => (
        <button key={i} className={"cep-pager-btn" + (i === page ? " active" : "")} onClick={() => onChange(i)}>{i + 1}</button>
      ))}
      <button className="cep-pager-btn" disabled={page === pages - 1} onClick={() => onChange(page + 1)} aria-label="Next">
        <Icon name="chevron-right" size={15} />
      </button>
    </div>
  );
}

function ReachOutCard({ r, onOpen }) {
  return (
    <div className="cep-reachout" onClick={() => onOpen(r)}>
      <div className="cep-reachout-top">
        <div className="cep-reachout-eyebrow">{r.intent}</div>
        <StatusBadge status={r.status} />
      </div>
      <div className="cep-reachout-title">{r.title}</div>
      <div className="cep-mono-block">{r.promptPreview}</div>
      <div className="cep-reachout-foot">{r.recipient.name} · {r.date}</div>
    </div>
  );
}

function ReachOutDetail({ r, onBack, theme }) {
  const [showPrompt, setShowPrompt] = useActState(false);
  return (
    <div className="cep-page cep-page-narrow cep-fade">
      <button className="cep-back" onClick={onBack}><Icon name="arrow-left" size={15} /> Activity</button>
      <div className="cep-page-head">
        <div className="cep-page-title">{r.title}</div>
        <div className="cep-page-sub">Reach out</div>
      </div>

      <div className="cep-card" style={{ padding: 20, marginBottom: 30 }}>
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 12 }}>
          <div>
            <div className="cep-list-name" style={{ fontSize: 16 }}>{r.recipient.name}</div>
            <div className="cep-list-desc">{r.recipient.email}</div>
          </div>
          <StatusBadge status={r.status} />
        </div>
        <div className="cep-reachout-eyebrow" style={{ marginTop: 18 }}>{r.intent}</div>
        <div style={{ fontSize: 14, marginTop: 6 }}>{r.topic}</div>
        <button className={"cep-collapse" + (showPrompt ? " open" : "")} style={{ marginTop: 10 }} onClick={() => setShowPrompt((v) => !v)}>
          <Icon name="chevron-down" size={15} /> view agent prompt
        </button>
        {showPrompt ? <div className="cep-prompt-box cep-fade-in">{r.agentPrompt}</div> : null}
      </div>

      <div className="cep-section-title"><Icon name="messages-square" size={15} /> Conversation</div>
      {r.conversation.length ? (
        <div className="cep-msglist" style={{ overflow: "visible", gap: 18 }}>
          {r.conversation.map((m, i) => m.role === "ai" ? (
            <div className="cep-msg ai" key={i}>
              <Avatar logo theme={theme} />
              <div className="cep-msg-body">
                <span className="cep-who">Ceptly · {m.time}</span>
                <div className="cep-bubble">{withIssues(m.text)}</div>
              </div>
            </div>
          ) : (
            <div className="cep-msg user" key={i}>
              <div className="cep-msg-body">
                <span className="cep-who">{r.recipient.name} · {m.time}</span>
                <div className="cep-bubble">{withIssues(m.text)}</div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="cep-card" style={{ padding: 20 }}>
          <p className="cep-card-empty" style={{ marginTop: 0 }}>This reach-out was abandoned before any messages were exchanged.</p>
        </div>
      )}
    </div>
  );
}

function ActivityScreenImpl({ theme = "dark" }) {
  const [openStandup, setOpenStandup] = useActState(null);
  const [openReach, setOpenReach] = useActState(null);
  const [warnings, setWarnings] = useActState(WARNINGS);
  const [roPage, setRoPage] = useActState(0);
  const RO_PER_PAGE = 3;
  const roPages = Math.ceil(REACHOUTS.length / RO_PER_PAGE);
  const roSlice = REACHOUTS.slice(roPage * RO_PER_PAGE, roPage * RO_PER_PAGE + RO_PER_PAGE);

  if (openStandup) return <StandupDetail s={openStandup} onBack={() => setOpenStandup(null)} />;
  if (openReach) return <ReachOutDetail r={openReach} theme={theme} onBack={() => setOpenReach(null)} />;

  const attention = STANDUPS.filter((s) => s.attention).length;

  return (
    <div className="cep-page">
      <div className="cep-page-head">
        <div className="cep-page-title">Activity</div>
        <div className="cep-page-sub">
          Rollups from your check-ins, standups, and one-off reach-outs.
          {attention ? <Badge variant="attention">{attention} need attention</Badge> : null}
        </div>
      </div>

      {warnings.length ? (
        <div className="cep-section">
          <div className="cep-section-title"><Icon name="triangle-alert" size={15} /> Needs your attention</div>
          <div className="cep-list-card">
            {warnings.map((w) => (
              <div className="cep-warn-row" key={w.id}>
                <span className="cep-warn-ico"><Icon name="mail-warning" size={18} /></span>
                <div className="cep-warn-main">
                  <div className="cep-warn-title">{w.title}</div>
                  <div className="cep-warn-desc">{w.desc}</div>
                </div>
                <button className="cep-warn-x" aria-label="Dismiss" onClick={() => setWarnings((cur) => cur.filter((x) => x.id !== w.id))}>
                  <Icon name="x" size={16} />
                </button>
              </div>
            ))}
          </div>
        </div>
      ) : null}

      <div className="cep-section">
        <div className="cep-section-title"><Icon name="calendar-check" size={15} /> Standups</div>
        <div className="cep-card-grid">
          {STANDUPS.map((s) => <StandupCard key={s.id} s={s} onOpen={setOpenStandup} />)}
        </div>
      </div>

      <div className="cep-section">
        <div className="cep-section-title"><Icon name="send" size={15} /> Recent reach-outs</div>
        <div>
          {roSlice.map((r) => <ReachOutCard key={r.id} r={r} onOpen={setOpenReach} />)}
        </div>
        <Pager page={roPage} pages={roPages} onChange={setRoPage} />
        <div className="cep-pager-info">
          Showing {roPage * RO_PER_PAGE + 1}–{Math.min((roPage + 1) * RO_PER_PAGE, REACHOUTS.length)} of {REACHOUTS.length} reach-outs
        </div>
      </div>
    </div>
  );
}

window.ActivityScreen = ActivityScreenImpl;
