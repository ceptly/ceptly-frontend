/* global React, Icon, Badge, Avatar */
// Ceptly — Deploy Agent shared kit: data + reusable pieces. Exports to window.

const AGENT_TYPES = [
  { id: "checkin",  name: "Scheduled check-in", icon: "calendar-clock", desc: "DMs each teammate on a cadence." },
  { id: "reachout", name: "One-off reach-out",   icon: "send",          desc: "A single Slack DM with a goal." },
  { id: "channel",  name: "Channel standup",     icon: "hash",          desc: "Broadcast or sequential in a channel." },
  { id: "custom",   name: "Custom autonomous",   icon: "sparkles",      desc: "Free-form role, goal, and triggers." },
];

const AGENT_PEOPLE = [
  { name: "Trey Chen", initials: "TC" },
  { name: "Mara Olsen", initials: "MO" },
  { name: "Sam Rivera", initials: "SR" },
  { name: "Devin Park", initials: "DP" },
  { name: "Priya Nair", initials: "PN" },
];

const AGENT_CHANNELS = ["#eng-standup", "#design", "#support", "#product"];

const AGENT_CADENCES = ["Every weekday", "Mon / Wed / Fri", "Weekly · Mon", "Daily"];
const AGENT_EVENTS = ["Linear issue moved", "PR merged", "Sprint closed", "New teammate added"];

const TIME_OPTIONS = Array.from({ length: 96 }).map((_, i) => {
  const h24 = Math.floor(i / 4);
  const m = (i % 4) * 15;
  const ampm = h24 < 12 ? "AM" : "PM";
  const h12 = h24 === 0 ? 12 : h24 > 12 ? h24 - 12 : h24;
  return `${h12}:${String(m).padStart(2, "0")} ${ampm}`;
});

const ACTIVE_AGENTS = [
  { name: "Daily Engineering Standup", type: "checkin", icon: "calendar-clock", meta: "Sequential · #eng-standup · 9:00 AM weekdays", live: true },
  { name: "Support Triage Pulse", type: "channel", icon: "hash", meta: "Broadcast · #support · 8:30 AM daily", live: true },
  { name: "Sprint Retro Collector", type: "checkin", icon: "calendar-clock", meta: "Weekly · DM · 5 people", live: true },
  { name: "Onboarding Buddy", type: "custom", icon: "sparkles", meta: "Event · new teammate added", live: false },
];

// Default working config used by every layout direction
function defaultAgentConfig() {
  return {
    type: "checkin",
    role: "You are Ceptly, a calm, capable chief of staff. You DM each teammate for a short, conversational standup — progress, blockers, and anything they need. One question at a time; stop once the picture is clear.",
    goal: "Capture daily progress and surface blockers before they slow the Friday release.",
    recipients: ["Trey Chen", "Mara Olsen", "Sam Rivera"],
    channel: "#eng-standup",
    trigger: "schedule",
    cadence: "Every weekday",
    time: "9:00 AM",
    event: "Linear issue moved",
  };
}

function agentTypeOf(id) { return AGENT_TYPES.find((t) => t.id === id) || AGENT_TYPES[0]; }
function initialsOf(name) { return name.split(" ").map((p) => p[0]).join("").slice(0, 2); }

// Build the opening message the agent would send, as renderable segments.
function openingSegments(cfg) {
  const first = (cfg.recipients[0] || "your teammate").split(" ")[0];
  const t = cfg.type;
  if (t === "channel") {
    return [
      { tok: cfg.channel }, { text: " standup is open. " },
      { text: "Drop your update when you get a sec — what you shipped, what's blocking you, and what's next. I'll roll it up for the leads." },
    ];
  }
  if (t === "reachout") {
    return [
      { text: "Hi " }, { tok: "@" + first }, { text: "! Quick one from your team lead — " },
      { text: (cfg.goal || "a short follow-up.").replace(/\.$/, "") + ". " },
      { text: "Got a moment?" },
    ];
  }
  if (t === "custom") {
    return [
      { text: "Hi " }, { tok: "@" + first }, { text: " — Ceptly here. " },
      { text: cfg.goal || "Checking in on your behalf." },
    ];
  }
  return [
    { text: "Morning " }, { tok: "@" + first }, { text: "! Standup time. " },
    { text: "What did you wrap yesterday, what's on for today, and is anything blocking you? Reply here whenever — I'll handle the rollup." },
  ];
}

function OpeningMessage({ cfg }) {
  return (
    <div className="ag-slack-msg">
      {openingSegments(cfg).map((s, i) => s.tok
        ? <span key={i} className="ag-tok">{s.tok}</span>
        : <React.Fragment key={i}>{s.text}</React.Fragment>)}
    </div>
  );
}

// ---- Agent-type selector grid ----
function AgentTypeGrid({ value, onChange }) {
  return (
    <div className="ag-type-grid">
      {AGENT_TYPES.map((t) => (
        <button key={t.id} className={"ag-type" + (value === t.id ? " active" : "")} onClick={() => onChange(t.id)}>
          <span className="ag-type-ico"><Icon name={t.icon} size={18} /></span>
          <span>
            <span className="ag-type-name">{t.name}</span>
            <span className="ag-type-desc">{t.desc}</span>
          </span>
          <span className="ag-type-check"><Icon name="check" size={15} /></span>
        </button>
      ))}
    </div>
  );
}

// ---- Recipient chips ----
function RecipientChips({ recipients, onRemove, onAdd }) {
  return (
    <div className="ag-chips">
      {recipients.map((r) => (
        <span className="ag-chip" key={r}>
          <span className="cep-avatar">{initialsOf(r)}</span>
          {r}
          {onRemove ? <span className="ag-chip-x" onClick={() => onRemove(r)}><Icon name="x" size={13} /></span> : null}
        </span>
      ))}
      {onAdd ? <button className="ag-chip-add" onClick={onAdd}><Icon name="plus" size={13} /> Add people</button> : null}
    </div>
  );
}

// ---- Trigger segmented control ----
function TriggerControls({ trigger, onChange }) {
  const opts = [
    { id: "schedule", label: "On a schedule", icon: "calendar-clock" },
    { id: "event", label: "On an event", icon: "zap" },
    { id: "manual", label: "Manually", icon: "hand" },
  ];
  return (
    <div className="cep-segment" role="tablist">
      {opts.map((o) => (
        <button key={o.id} className={trigger === o.id ? "active" : ""} onClick={() => onChange(o.id)}>
          <Icon name={o.icon} size={14} /> {o.label}
        </button>
      ))}
    </div>
  );
}

function CadencePills({ trigger, cfg, set }) {
  if (trigger === "manual") {
    return <p className="cep-field-hint" style={{ marginTop: 0 }}>Runs only when you trigger it from this page or chat.</p>;
  }
  const list = trigger === "event" ? AGENT_EVENTS : AGENT_CADENCES;
  const key = trigger === "event" ? "event" : "cadence";
  return (
    <div className="ag-cadence">
      {list.map((c) => (
        <button key={c} className={"ag-pill" + (cfg[key] === c ? " active" : "")} onClick={() => set(key, c)}>{c}</button>
      ))}
    </div>
  );
}

// ---- Live preview rail ----
function SlackPreview({ cfg, theme }) {
  return (
    <div className="ag-preview">
      <div className="ag-preview-head"><Icon name="message-square" size={13} /> Live preview</div>
      <div className="ag-slack">
        <Avatar logo theme={theme} />
        <div className="ag-slack-body">
          <div className="ag-slack-name">
            <b>Ceptly</b><span className="ag-slack-tag">APP</span><span className="ag-slack-time">{cfg.time || "9:00 AM"}</span>
          </div>
          <OpeningMessage cfg={cfg} />
        </div>
      </div>
    </div>
  );
}

function triggerLabel(cfg) {
  if (cfg.trigger === "manual") return "Manual";
  if (cfg.trigger === "event") return cfg.event;
  return `${cfg.cadence} · ${cfg.time || "9:00 AM"}`;
}

function TimeSelect({ value, onChange }) {
  return (
    <div>
      <label className="cep-label">Run at</label>
      <select className="cep-select-block" style={{ maxWidth: 164 }} value={value} onChange={(e) => onChange(e.target.value)}>
        {TIME_OPTIONS.map((t) => <option key={t} value={t}>{t}</option>)}
      </select>
    </div>
  );
}

function ConfigSummary({ cfg }) {
  const type = agentTypeOf(cfg.type);
  const audience = cfg.type === "channel" ? cfg.channel : `${cfg.recipients.length} ${cfg.recipients.length === 1 ? "person" : "people"}`;
  const rows = [
    { icon: type.icon, k: "Type", v: type.name },
    { icon: "target", k: "Goal", v: cfg.goal },
    { icon: cfg.type === "channel" ? "hash" : "users", k: "Audience", v: audience },
    { icon: "git-branch", k: "Channel", v: cfg.channel },
    { icon: cfg.trigger === "event" ? "zap" : "calendar-clock", k: "Trigger", v: triggerLabel(cfg) },
  ];
  return (
    <div className="ag-summary">
      {rows.map((r) => (
        <div className="ag-sum-row" key={r.k}>
          <Icon name={r.icon} size={14} />
          <span className="ag-sum-k">{r.k}</span>
          <span className="ag-sum-v">{r.v}</span>
        </div>
      ))}
    </div>
  );
}

function DeployBar({ onDeploy }) {
  return (
    <div className="ag-deploy-bar">
      <button className="cep-btn cep-btn-default cep-btn-block" onClick={onDeploy}><Icon name="rocket" size={15} /> Deploy agent</button>
      <button className="cep-btn cep-btn-outline"><Icon name="flask-conical" size={15} /> Test</button>
    </div>
  );
}

// ---- success toast (auto-dismisses via parent; CSS plays the full in/out) ----
function AgentToast({ title = "Agent deployed", sub = "It's live and will start running on schedule." }) {
  return (
    <div className="ag-toast" role="status" aria-live="polite">
      <span className="ag-toast-ico"><Icon name="check" size={16} /></span>
      <div className="ag-toast-text">
        <div className="ag-toast-title">{title}</div>
        <div className="ag-toast-sub">{sub}</div>
      </div>
      <span className="ag-toast-bar" />
    </div>
  );
}

// ---- celebratory "Agent deployed" dialog: confetti + drawing check ----
const AG_CONFETTI_COLORS = ["#56FF3C", "#B1FFA5", "#ffffff", "#3DBE26", "#e9ffe4", "#7CFF63"];
function AgentDeployedDialog({ name = "Your agent", detail, onClose }) {
  const pieces = React.useMemo(() => Array.from({ length: 30 }).map((_, i) => {
    const tx = (Math.random() * 2 - 1) * 320;
    const ty = (Math.random() * 2 - 1) * 110 + 200;
    const rot = Math.random() * 760 - 200;
    const w = 6 + Math.random() * 7;
    return {
      "--tx": tx + "px", "--ty": ty + "px", "--rot": rot + "deg",
      "--c": AG_CONFETTI_COLORS[i % AG_CONFETTI_COLORS.length],
      width: w + "px", height: (w * 1.7) + "px",
      borderRadius: Math.random() < 0.4 ? "50%" : "1px",
      animationDelay: (Math.random() * 0.18) + "s",
      animationDuration: (1.15 + Math.random() * 0.8) + "s",
    };
  }), []);
  return (
    <div className="ag-modal" role="dialog" aria-modal="true" aria-label="Agent deployed">
      <div className="ag-modal-backdrop" onClick={onClose} />
      <div className="ag-confetti" aria-hidden="true">
        {pieces.map((st, i) => <i key={i} style={st} />)}
      </div>
      <div className="ag-modal-card">
        <div className="ag-check">
          <span className="ag-check-ring" />
          <svg viewBox="0 0 52 52" aria-hidden="true">
            <circle className="ag-check-circle" cx="26" cy="26" r="24" />
            <path className="ag-check-tick" d="M15 27 l7 7 l15 -16" />
          </svg>
        </div>
        <h2 className="ag-modal-title">Agent deployed</h2>
        <p className="ag-modal-sub"><b>{name}</b> is live{detail ? <React.Fragment><br />{detail}</React.Fragment> : null}</p>
        <button className="cep-btn cep-btn-default cep-btn-block" onClick={onClose}>
          View my agents <Icon name="arrow-right" size={15} />
        </button>
      </div>
    </div>
  );
}

// ---- Active agents list ----
function ActiveAgentRow({ a }) {
  return (
    <div className="ag-agent-row">
      <span className="ag-agent-ico"><Icon name={a.icon} size={17} /></span>
      <div className="ag-agent-main">
        <div className="ag-agent-name">{a.name}</div>
        <div className="ag-agent-meta"><span className={"ag-dot" + (a.live ? "" : " paused")} />{a.live ? "Active" : "Paused"} · {a.meta}</div>
      </div>
      <div className="ag-agent-actions">
        <button className="cep-btn cep-btn-ghost cep-btn-sm"><Icon name={a.live ? "pause" : "play"} size={14} /></button>
        <button className="cep-btn cep-btn-ghost cep-btn-sm"><Icon name="ellipsis" size={14} /></button>
      </div>
    </div>
  );
}

function NewAgentCard({ onClick }) {
  return (
    <button className="ag-new-card" onClick={onClick}>
      <span className="ag-new-ico"><Icon name="plus" size={18} /></span>
      <span>
        <span className="ag-agent-name">Deploy a new agent</span>
        <div className="ag-agent-meta" style={{ marginTop: 3 }}>Check-in, reach-out, channel standup, or custom</div>
      </span>
      <Icon name="arrow-right" size={16} />
    </button>
  );
}

Object.assign(window, {
  AGENT_TYPES, AGENT_PEOPLE, AGENT_CHANNELS, AGENT_CADENCES, AGENT_EVENTS, ACTIVE_AGENTS,
  defaultAgentConfig, agentTypeOf, initialsOf, OpeningMessage,
  AgentTypeGrid, RecipientChips, TriggerControls, CadencePills, TimeSelect,
  SlackPreview, ConfigSummary, DeployBar, AgentToast, AgentDeployedDialog, ActiveAgentRow, NewAgentCard,
});
