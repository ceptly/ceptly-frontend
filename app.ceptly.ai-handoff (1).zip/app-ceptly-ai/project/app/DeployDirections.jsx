/* global React, Icon, Badge, Avatar, AgentTypeGrid, RecipientChips, TriggerControls, CadencePills, SlackPreview, ConfigSummary, DeployBar, ActiveAgentRow, NewAgentCard, ACTIVE_AGENTS, AGENT_CHANNELS, defaultAgentConfig, agentTypeOf */
// Ceptly — Deploy Agent: three layout directions (A console, B guided, C dashboard).

const { useState: useAgState } = React;

function useAgentCfg() {
  const [cfg, setCfg] = useAgState(defaultAgentConfig());
  const set = (k, v) => setCfg((c) => ({ ...c, [k]: v }));
  return [cfg, set];
}

// ---- shared field bits ----
function PersonaFields({ cfg, set }) {
  return (
    <React.Fragment>
      <div>
        <label className="cep-label">Role / persona</label>
        <textarea className="cep-textarea" rows={4} value={cfg.role} onChange={(e) => set("role", e.target.value)} />
        <p className="cep-field-hint">The system prompt that shapes how the agent speaks and behaves.</p>
      </div>
      <div>
        <label className="cep-label">Goal / intent</label>
        <input className="cep-input" value={cfg.goal} onChange={(e) => set("goal", e.target.value)} />
      </div>
    </React.Fragment>
  );
}

function ChannelPicker({ cfg, set }) {
  return (
    <div className="ag-chips">
      {AGENT_CHANNELS.map((ch) => (
        <button key={ch} className={"ag-pill" + (cfg.channel === ch ? " active" : "")} onClick={() => set("channel", ch)}>
          <span className="ag-chip-hash">#</span>{ch.replace(/^#/, "")}
        </button>
      ))}
    </div>
  );
}

function AudienceFields({ cfg, set }) {
  const isChannel = cfg.type === "channel";
  return (
    <React.Fragment>
      {!isChannel ? (
        <div>
          <label className="cep-label">Recipients</label>
          <RecipientChips recipients={cfg.recipients}
            onRemove={(r) => set("recipients", cfg.recipients.filter((x) => x !== r))}
            onAdd={() => {}} />
        </div>
      ) : null}
      <div>
        <label className="cep-label">{isChannel ? "Channel" : "Where rollups land"}</label>
        <ChannelPicker cfg={cfg} set={set} />
      </div>
    </React.Fragment>
  );
}

function TriggerFields({ cfg, set }) {
  return (
    <React.Fragment>
      <TriggerControls trigger={cfg.trigger} onChange={(v) => set("trigger", v)} />
      <CadencePills trigger={cfg.trigger} cfg={cfg} set={set} />
      {cfg.trigger === "schedule" ? (
        <TimeSelect value={cfg.time || "9:00 AM"} onChange={(v) => set("time", v)} />
      ) : null}
    </React.Fragment>
  );
}

function GroupHead({ num, title, sub }) {
  return (
    <div>
      <div className="ag-group-head">
        {num ? <span className="ag-group-num">{num}</span> : null}
        <span className="ag-group-title">{title}</span>
      </div>
      {sub ? <div className="ag-group-sub" style={{ marginTop: 8, marginLeft: num ? 31 : 0 }}>{sub}</div> : null}
    </div>
  );
}

/* =====================================================================
   DIRECTION A — split: config form (left) · live-preview rail (right)
   Active/existing agents live on a separate page.
   ===================================================================== */
function AgentDeployForm({ theme = "dark", onBack, onDeploy }) {
  const [cfg, set] = useAgentCfg();
  const [done, setDone] = useAgState(false);
  const dlgT = React.useRef();
  function handleDeploy() {
    if (onDeploy) { onDeploy(cfg); return; }
    // standalone fallback: celebrate, then dismiss on its own
    setDone(true);
    clearTimeout(dlgT.current);
    dlgT.current = setTimeout(() => setDone(false), 4200);
  }
  return (
    <div className="ag-page ag-page-wide" style={{ maxWidth: 1100, margin: "0 auto" }}>
      <button className="cep-back" onClick={onBack}><Icon name="arrow-left" size={15} /> Agents</button>
      <div className="ag-head">
        <div>
          <div className="ag-head-eyebrow">New agent</div>
          <h1>Deploy an agent</h1>
          <p>Configure the agent on the left — the preview shows the first message it'll send and a summary of what you're shipping.</p>
        </div>
      </div>

      <div className="ag-split">
        {/* config form */}
        <div className="ag-form">
          <div className="ag-group">
            <GroupHead title="Agent type" />
            <AgentTypeGrid value={cfg.type} onChange={(v) => set("type", v)} />
          </div>
          <div className="ag-divider" />
          <div className="ag-group"><GroupHead title="Persona" /><PersonaFields cfg={cfg} set={set} /></div>
          <div className="ag-divider" />
          <div className="ag-group"><GroupHead title="Audience" /><AudienceFields cfg={cfg} set={set} /></div>
          <div className="ag-divider" />
          <div className="ag-group"><GroupHead title="Trigger" /><TriggerFields cfg={cfg} set={set} /></div>
        </div>

        {/* live-preview rail */}
        <div className="ag-rail">
          <SlackPreview cfg={cfg} theme={theme} />
          <div className="ag-preview">
            <div className="ag-preview-head"><Icon name="list-checks" size={13} /> Summary</div>
            <ConfigSummary cfg={cfg} />
            <DeployBar onDeploy={handleDeploy} />
          </div>
        </div>
      </div>
      {done ? <AgentDeployedDialog name={agentTypeOf(cfg.type).name} detail={(cfg.trigger === "manual" ? "Manual" : cfg.trigger === "event" ? cfg.event : cfg.cadence) + " · " + cfg.channel} onClose={() => setDone(false)} /> : null}
    </div>
  );
}

function DirectionA({ theme = "dark" }) {
  return (
    <div className="cep-app dark ag-host">
      <AgentDeployForm theme={theme} />
    </div>
  );
}

/* =====================================================================
   DIRECTION B — "Guided": stepper · current step · preview
   ===================================================================== */
const B_STEPS = [
  { id: "type", num: "1", label: "Type", title: "What kind of agent?", sub: "Pick the behavior. You can change everything later." },
  { id: "persona", num: "2", label: "Persona", title: "Give it a voice", sub: "Role and goal shape every message it sends." },
  { id: "audience", num: "3", label: "Audience", title: "Who does it talk to?", sub: "People to DM, and where rollups land." },
  { id: "trigger", num: "4", label: "Trigger", title: "When does it run?", sub: "On a schedule, on an event, or on demand." },
];

function DirectionB({ theme = "dark" }) {
  const [cfg, set] = useAgentCfg();
  const [step, setStep] = useAgState(1);
  const cur = B_STEPS[step - 1];
  return (
    <div className="cep-app dark ag-host">
      <div className="ag-page ag-page-wide">
        <div className="ag-head">
          <div>
            <div className="ag-head-eyebrow">New agent</div>
            <h1>Deploy an agent</h1>
            <p>Four quick steps. The preview on the right fills in as you go.</p>
          </div>
          <button className="cep-btn cep-btn-outline cep-btn-sm"><Icon name="layout-list" size={14} /> 4 active agents</button>
        </div>

        <div className="ag-split" style={{ gridTemplateColumns: "190px 1fr 340px" }}>
          {/* stepper */}
          <div className="ag-stepper">
            {B_STEPS.map((s, i) => (
              <button key={s.id} className={"ag-step" + (step === i + 1 ? " active" : "") + (step > i + 1 ? " done" : "")} onClick={() => setStep(i + 1)}>
                <span className="ag-step-num">{step > i + 1 ? <Icon name="check" size={13} /> : s.num}</span>
                <span className="ag-step-label">{s.label}</span>
              </button>
            ))}
          </div>

          {/* current step */}
          <div className="ag-form" style={{ gap: 18 }}>
            <GroupHead title={cur.title} sub={cur.sub} />
            {cur.id === "type" ? <AgentTypeGrid value={cfg.type} onChange={(v) => set("type", v)} /> : null}
            {cur.id === "persona" ? <PersonaFields cfg={cfg} set={set} /> : null}
            {cur.id === "audience" ? <AudienceFields cfg={cfg} set={set} /> : null}
            {cur.id === "trigger" ? <TriggerFields cfg={cfg} set={set} /> : null}
            <div style={{ display: "flex", gap: 9, marginTop: 6 }}>
              <button className="cep-btn cep-btn-ghost" disabled={step === 1} onClick={() => setStep((s) => Math.max(1, s - 1))}><Icon name="arrow-left" size={15} /> Back</button>
              {step < 4
                ? <button className="cep-btn cep-btn-default" onClick={() => setStep((s) => Math.min(4, s + 1))}>Continue <Icon name="arrow-right" size={15} /></button>
                : <button className="cep-btn cep-btn-default"><Icon name="rocket" size={15} /> Deploy agent</button>}
            </div>
          </div>

          {/* preview */}
          <div className="ag-rail">
            <SlackPreview cfg={cfg} theme={theme} />
            <div className="ag-preview">
              <div className="ag-preview-head"><Icon name="list-checks" size={13} /> Summary</div>
              <ConfigSummary cfg={cfg} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* =====================================================================
   DIRECTION C — "Dashboard": agent cards on top · split form below
   ===================================================================== */
function AgentStatusCard({ a }) {
  return (
    <div className="cep-card" style={{ padding: 16 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <span className="ag-agent-ico"><Icon name={a.icon} size={17} /></span>
        <Badge variant={a.live ? "green" : "secondary"}>{a.live ? "Active" : "Paused"}</Badge>
      </div>
      <div className="ag-agent-name" style={{ marginTop: 12 }}>{a.name}</div>
      <div className="ag-agent-meta" style={{ marginTop: 4 }}>{a.meta}</div>
    </div>
  );
}

function DirectionC({ theme = "dark" }) {
  const [cfg, set] = useAgentCfg();
  return (
    <div className="cep-app dark ag-host">
      <div className="ag-page ag-page-wide">
        <div className="ag-head">
          <div>
            <div className="ag-head-eyebrow">Agents</div>
            <h1>Your agents</h1>
            <p>Ceptly runs these on your behalf — without status meetings.</p>
          </div>
          <button className="cep-btn cep-btn-default"><Icon name="plus" size={15} /> New agent</button>
        </div>

        {/* active agents grid */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 30 }}>
          {ACTIVE_AGENTS.map((a) => <AgentStatusCard key={a.name} a={a} />)}
        </div>

        <div className="ag-divider" style={{ marginBottom: 24 }} />

        {/* deploy form */}
        <div style={{ marginBottom: 18 }}>
          <GroupHead title="Deploy a new agent" sub="Choose a type, give it a goal, point it at your team." />
        </div>
        <div className="ag-split">
          <div className="ag-form">
            <AgentTypeGrid value={cfg.type} onChange={(v) => set("type", v)} />
            <div className="ag-divider" />
            <PersonaFields cfg={cfg} set={set} />
            <div className="cep-field-grid">
              <div>
                <label className="cep-label">Trigger</label>
                <TriggerControls trigger={cfg.trigger} onChange={(v) => set("trigger", v)} />
              </div>
              <div>
                <label className="cep-label">{cfg.trigger === "event" ? "Event" : "Cadence"}</label>
                <CadencePills trigger={cfg.trigger} cfg={cfg} set={set} />
              </div>
            </div>
            <AudienceFields cfg={cfg} set={set} />
          </div>
          <div className="ag-rail">
            <SlackPreview cfg={cfg} theme={theme} />
            <div className="ag-preview">
              <div className="ag-preview-head"><Icon name="list-checks" size={13} /> Summary</div>
              <ConfigSummary cfg={cfg} />
              <DeployBar />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { AgentDeployForm, DirectionA, DirectionB, DirectionC });
