/* global React, Icon, ActiveAgentRow, ACTIVE_AGENTS, AgentDeployForm, AgentDeployedDialog, agentTypeOf */
// Ceptly App — Agents: active-agents list + entry into the deploy form.

function agentFromCfg(cfg) {
  const t = agentTypeOf(cfg.type);
  const audience = cfg.type === "channel"
    ? cfg.channel
    : `${cfg.recipients.length} ${cfg.recipients.length === 1 ? "person" : "people"}`;
  const when = cfg.trigger === "manual" ? "Manual" : cfg.trigger === "event" ? cfg.event : cfg.cadence;
  return { name: t.name, type: cfg.type, icon: t.icon, meta: `${when} · ${cfg.channel} · ${audience}`, live: true, isNew: true };
}

function AgentsListView({ agents, onNew }) {
  const live = agents.filter((a) => a.live);
  const paused = agents.filter((a) => !a.live);
  return (
    <div className="cep-page">
      <div className="cep-page-head" style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 16, flexWrap: "wrap" }}>
        <div>
          <div className="cep-page-title">Agents</div>
          <div className="cep-page-sub">Autonomous agents Ceptly runs on your behalf — scheduled check-ins, channel standups, and one-off reach-outs.</div>
        </div>
        <button className="cep-btn cep-btn-default" onClick={onNew}><Icon name="plus" size={15} /> New agent</button>
      </div>

      <div className="cep-section">
        <div className="cep-section-title"><Icon name="bot" size={15} /> Active <span className="cep-count">{live.length}</span></div>
        <div className="cep-list-card ag-active">
          {live.map((a, i) => (
            <div key={a.name + i} className={a.isNew ? "ag-row-new" : ""}>
              <ActiveAgentRow a={a} />
            </div>
          ))}
        </div>
      </div>

      {paused.length ? (
        <div className="cep-section">
          <div className="cep-section-title"><Icon name="pause" size={15} /> Paused <span className="cep-count">{paused.length}</span></div>
          <div className="cep-list-card ag-active">
            {paused.map((a, i) => <ActiveAgentRow key={a.name + i} a={a} />)}
          </div>
        </div>
      ) : null}
    </div>
  );
}

function AgentsScreen({ theme = "dark" }) {
  const [view, setView] = React.useState("list");
  const [agents, setAgents] = React.useState(ACTIVE_AGENTS);
  const [deployed, setDeployed] = React.useState(null);
  const dlgT = React.useRef();

  function deploy(cfg) {
    const a = agentFromCfg(cfg);
    setAgents((prev) => [a, ...prev.map((x) => ({ ...x, isNew: false }))]);
    setView("list");
    setDeployed(a);
    clearTimeout(dlgT.current);
    dlgT.current = setTimeout(() => setDeployed(null), 4200);
  }
  function closeDialog() { clearTimeout(dlgT.current); setDeployed(null); }

  return (
    <React.Fragment>
      {view === "new"
        ? <AgentDeployForm theme={theme} onBack={() => setView("list")} onDeploy={deploy} />
        : <AgentsListView agents={agents} onNew={() => setView("new")} />}
      {deployed ? <AgentDeployedDialog name={deployed.name} detail={deployed.meta} onClose={closeDialog} /> : null}
    </React.Fragment>
  );
}

window.AgentsScreen = AgentsScreen;
