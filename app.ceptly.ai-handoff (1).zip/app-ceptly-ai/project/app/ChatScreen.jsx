/* global React, Icon, Button, Badge, Avatar */
// Ceptly App — chat (empty state -> agent activity -> reach-out proposal)

const { useState: useChatState, useRef: useChatRef, useEffect: useChatEffect } = React;

const SUGGESTIONS = [
  { icon: "message-square", text: "Ask Trey about his blocker" },
  { icon: "calendar", text: "Set up a daily standup" },
  { icon: "sparkles", text: "How is morale this week?" },
];

const ACTIVITY_STEPS = [
  { icon: "sparkles", label: "Understanding your request", img: null },
  { icon: null, label: "Matching roster members", img: null },
  { icon: null, label: "Building reach-out plan", img: "assets/integrations-slack.png" },
];

function AgentActivity({ live, elapsed }) {
  const [shown, setShown] = useChatState(live ? 1 : ACTIVITY_STEPS.length);
  useChatEffect(() => {
    if (!live) { setShown(ACTIVITY_STEPS.length); return; }
    let n = 1; setShown(1);
    const t = setInterval(() => { n += 1; setShown(n); if (n >= ACTIVITY_STEPS.length) clearInterval(t); }, 520);
    return () => clearInterval(t);
  }, [live]);
  return (
    <div className="cep-activity">
      <div className="cep-activity-title">
        <Icon name="sparkles" size={13} color="#56FF3C" className={live ? "cep-pulse" : ""} />
        {live ? "Reach out · working…" : `Reach out · ${elapsed || "2.4s"}`}
      </div>
      {ACTIVITY_STEPS.slice(0, shown).map((s, i) => (
        <div key={i} className={"cep-activity-step" + (!live || i < shown - 1 ? " done" : "")}>
          {s.img ? <img src={s.img} alt="" /> : <Icon name={s.icon || "check"} size={13} color={(!live || i < shown - 1) ? "#56FF3C" : undefined} />}
          <span>{s.label}</span>
          {live && i === shown - 1 ? <Icon name="loader-2" size={12} className="cep-spin" /> : null}
        </div>
      ))}
    </div>
  );
}

function ReachOutProposal({ onStart, done, pending }) {
  return (
    <div className="cep-proposal">
      <div className="cep-proposal-head">
        <Icon name="message-square" size={14} /> Reach out · Slack DM
      </div>
      <div className="cep-proposal-eyebrow">Gather information</div>
      <p className="cep-proposal-body">
        Ask Trey about his blocker on the dashboard empty-state screens, and follow up until the situation is clear.
      </p>
      <div className="cep-proposal-row"><span className="k">Recipient</span><span className="v">Trey Chen</span></div>
      <div className="cep-proposal-row"><span className="k">Channel</span><span className="v">Slack DM</span></div>
      <div className="cep-proposal-row"><span className="k">Results land in</span><span className="v">Team insights</span></div>
      <div className="cep-proposal-goal">
        <Icon name="target" size={13} />
        <span>Goal: message the recipient until Ceptly has a clear picture.</span>
      </div>
      <Button variant="default" size="sm" style={{ marginTop: 14 }} onClick={onStart} disabled={done || pending}>
        {pending ? <><Icon name="loader-2" size={13} className="cep-spin" /> Starting…</>
          : done ? <><Icon name="check" size={13} /> Message sent to Trey</>
            : <>Message Trey in Slack <Icon name="arrow-right" size={13} /></>}
      </Button>
    </div>
  );
}

function ChatScreen({ theme }) {
  const [messages, setMessages] = useChatState([]);
  const [input, setInput] = useChatState("");
  const [pending, setPending] = useChatState(false);
  const [agent, setAgent] = useChatState(null);
  const [started, setStarted] = useChatState(false);
  const [startPending, setStartPending] = useChatState(false);
  const [menuOpen, setMenuOpen] = useChatState(false);
  const [mode, setMode] = useChatState("Auto");
  const listRef = useChatRef(null);

  useChatEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, pending]);

  function send(text) {
    const t = text.trim();
    if (!t || pending) return;
    setMessages((m) => [...m, { role: "user", content: t }]);
    setInput(""); setPending(true); setAgent("Reach out");
    setTimeout(() => {
      setPending(false);
      setMessages((m) => [...m, {
        role: "ai",
        content: "Here's a plan to reach out in Slack. Review the details below and start when you're ready.",
        activity: true, proposal: true,
      }]);
    }, 1750);
  }

  function startReachOut() {
    setStartPending(true);
    setTimeout(() => { setStartPending(false); setStarted(true); }, 900);
  }

  const empty = messages.length === 0 && !pending;

  const composer = (
    <form className="cep-composer" onSubmit={(e) => { e.preventDefault(); send(input); }}>
      {agent ? <div className="cep-composer-tagbar"><Badge variant="secondary">{agent}</Badge></div> : null}
      <textarea rows={3}
        placeholder="Ask about your team — @ for people, # for channels. Enter to send, Shift+Enter for new line."
        value={input} onChange={(e) => setInput(e.target.value)}
        onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input); } }} />
      <div className="cep-composer-bar">
        <div style={{ position: "relative" }}>
          <button type="button" className="cep-composer-menu" onClick={() => setMenuOpen((o) => !o)}>
            {mode} <Icon name="chevron-down" size={13} />
          </button>
          {menuOpen ? (
            <div className="cep-menu cep-fade-in" style={{ right: "auto", left: 0, bottom: "calc(100% + 6px)", top: "auto", width: 180 }}>
              {["Auto", "Scheduling", "Team insights", "Reach out", "Channel standup"].map((m) => (
                <button key={m} className="cep-menu-item" onClick={() => { setMode(m); setMenuOpen(false); }}>
                  {mode === m ? <Icon name="check" size={14} /> : <span style={{ width: 14 }} />} {m}
                </button>
              ))}
            </div>
          ) : null}
        </div>
        <div style={{ display: "flex", gap: 0 }}>
          <Button type="button" variant="outline" size="icon-sm" aria-label="Dictate"><Icon name="mic" size={15} /></Button>
          <Button type="submit" variant="default" size="icon-sm" disabled={!input.trim() || pending} aria-label="Send">
            {pending ? <Icon name="loader-2" size={15} className="cep-spin" /> : <Icon name="arrow-up" size={15} />}
          </Button>
        </div>
      </div>
    </form>
  );

  if (empty) {
    return (
      <div className="cep-chat cep-chat--empty">
        <div className="cep-chat-col">
          <div className="cep-empty">
            <div className="cep-empty-head">
              <h1>What can I do for you?</h1>
            </div>
            {composer}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="cep-chat">
      <div className="cep-chat-col">
        <div className="cep-msglist" ref={listRef}>
          {messages.map((m, i) => m.role === "user" ? (
            <div className="cep-msg user cep-fade" key={i}>
              <div className="cep-msg-body">
                <span className="cep-who">You</span>
                <div className="cep-bubble">{m.content}</div>
              </div>
            </div>
          ) : (
            <div className="cep-msg ai cep-fade" key={i}>
              <Avatar logo theme={theme} />
              <div className="cep-msg-body">
                <span className="cep-who">Ceptly</span>
                {m.activity ? <AgentActivity /> : null}
                <div className="cep-bubble">{m.content}</div>
                {m.proposal ? <ReachOutProposal onStart={startReachOut} done={started} pending={startPending} /> : null}
              </div>
            </div>
          ))}
          {pending ? (
            <div className="cep-msg ai">
              <Avatar logo theme={theme} />
              <div className="cep-msg-body">
                <span className="cep-who">Ceptly</span>
                <AgentActivity live />
              </div>
            </div>
          ) : null}
        </div>

        {started ? (
          <p className="cep-chat-note">
            Conversation started in Slack. Replies show up in <a href="#">Team insights</a> once Trey responds.
          </p>
        ) : null}
        <div className="cep-newchat">
          <Button variant="outline" size="icon-sm" aria-label="New chat"
            onClick={() => { setMessages([]); setAgent(null); setStarted(false); }}>
            <Icon name="refresh-cw" size={15} />
          </Button>
        </div>
        {composer}
      </div>
    </div>
  );
}

window.ChatScreen = ChatScreen;
