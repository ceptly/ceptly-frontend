/* global React, Icon, Button, Field, Alert, GoogleIcon */
// Ceptly App — Auth (sign in / sign up / Google) with blueprint-grid motif

const { useState: useAuthState } = React;

function AuthScreen({ onSignIn, onSignUp, theme }) {
  const [mode, setMode] = useAuthState("sign-in");
  const isSignUp = mode === "sign-up";
  const [email, setEmail] = useAuthState("you@acme.com");
  const [name, setName] = useAuthState("");
  const [pw, setPw] = useAuthState("");

  function submit(e) {
    e.preventDefault();
    if (isSignUp) onSignUp({ email, name }); else onSignIn({ email });
  }

  return (
    <div className="cep-auth">
      <div className="cep-auth-bg">
        <div className="cep-grid-layer" />
        <div className="cep-dot-layer" />
        <div className="cep-watermark">
          <img src={theme === "light" ? "assets/parallax-light.png" : "assets/parallax-dark.png"} alt="" />
        </div>
      </div>

      <div className="cep-auth-card-wrap">
        <div className="cep-auth-mark cep-fade">
          <img src="assets/parallax-gradient.png" alt="Ceptly" />
        </div>

        <div className="cep-auth-card">
          <div className="cep-auth-head">
            <h1>{isSignUp ? "Create your Ceptly account" : "Welcome back"}</h1>
            <p>{isSignUp ? "Sign up with your email and password" : "Sign in to your Ceptly account"}</p>
          </div>

          <div className="cep-auth-form">
            <Button variant="outline" className="cep-btn-block" onClick={() => onSignIn({ email: "you@acme.com" })}>
              <GoogleIcon /> Continue with Google
            </Button>

            <div className="cep-or"><span>or</span></div>

            <form className="cep-auth-form" onSubmit={submit}>
              <Field label="Email" icon={isSignUp ? "mail" : undefined} id="email">
                <input id="email" className="cep-input" type="email" value={email}
                  onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required />
              </Field>

              {isSignUp ? (
                <Field label="Full name" icon="user" id="name">
                  <input id="name" className="cep-input" value={name}
                    onChange={(e) => setName(e.target.value)} placeholder="Jordan Avery" required />
                </Field>
              ) : null}

              <Field label="Password" icon={isSignUp ? "lock" : undefined} id="pw"
                hint={isSignUp ? "Must be at least 8 characters with a letter and a number" : undefined}>
                <input id="pw" className="cep-input" type="password" value={pw}
                  onChange={(e) => setPw(e.target.value)} placeholder="••••••••" required />
              </Field>

              <Button type="submit" variant="default" className="cep-btn-block">
                {isSignUp ? "Create account" : "Sign in"}
              </Button>
            </form>

            <div className="cep-auth-foot">
              {isSignUp ? "Already have an account? " : "Don't have an account? "}
              <button type="button" onClick={() => setMode(isSignUp ? "sign-in" : "sign-up")}>
                {isSignUp ? "Sign in" : "Create account"}
              </button>
            </div>

            <p className="cep-auth-fine">By continuing, you agree to our terms of service and privacy policy.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

window.AuthScreen = AuthScreen;
