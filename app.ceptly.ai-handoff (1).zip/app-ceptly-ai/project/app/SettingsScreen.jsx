/* global React, Icon, Button, Badge, Field */
// Ceptly App — Settings (sidebar sub-nav: team / account / integrations / standups / billing)

const { useState: useSetState, useEffect: useSetEffect } = React;

const NAV = [
  { id: "team", label: "Team settings", icon: "settings-2" },
  { id: "account", label: "Account", icon: "user" },
  { id: "integrations", label: "Integrations", icon: "plug" },
  { id: "standups", label: "Channel standups", icon: "hash" },
  { id: "billing", label: "Billing", icon: "credit-card" },
];

const INTEGRATIONS = (theme) => [
  { key: "slack", name: "Slack", logo: "assets/integrations/slack.png", desc: "Check-ins and reach-out run in Slack DMs", connected: true },
  { key: "linear", name: "Linear", logo: theme === "light" ? "assets/integrations/linear-dark.png" : "assets/integrations/linear-light.png", desc: "Issue-aware team insights and check-ins", connected: true },
  { key: "jira", name: "Jira", logo: "assets/integrations/Jira_icon.png", desc: "Sync issues into check-ins", connected: false },
  { key: "monday", name: "monday.com", logo: "assets/integrations/monday.png", desc: "Sync boards into check-ins", connected: false },
];

const CHANNEL_STANDUPS = [
  { name: "Daily Engineering Standup", channel: "#eng-standup", style: "Sequential", cadence: "Weekdays · 9:00 AM", on: true },
  { name: "Design Weekly Check-in", channel: "#design", style: "Broadcast", cadence: "Mondays · 10:00 AM", on: true },
  { name: "Support Triage", channel: "#support", style: "Broadcast", cadence: "Weekdays · 8:30 AM", on: false },
];

function Toggle({ on, onChange }) {
  return (
    <button type="button" onClick={() => onChange(!on)} aria-pressed={on}
      style={{
        width: 42, height: 24, borderRadius: 9999, border: "1px solid var(--border-2)",
        background: on ? "var(--green)" : "var(--muted)", position: "relative", padding: 0, flexShrink: 0,
      }}>
      <span style={{
        position: "absolute", top: 2, left: on ? 20 : 2, width: 18, height: 18, borderRadius: "50%",
        background: on ? "#09090b" : "var(--fg2)", transition: "left .18s ease",
      }} />
    </button>
  );
}

function IntegrationCard({ it }) {
  const [connected, setConnected] = useSetState(it.connected);
  return (
    <div className="cep-list-row" style={{ border: "1px solid var(--border-strong)", background: "var(--card-glass)" }}>
      <img className="cep-list-logo" src={it.logo} alt="" />
      <div className="cep-list-main">
        <div className="cep-list-name">{it.name}</div>
        <div className="cep-list-desc">{it.desc}</div>
      </div>
      {connected
        ? <Badge variant="green"><Icon name="check" size={12} /> Connected</Badge>
        : <Button variant="outline" size="sm" onClick={() => setConnected(true)}>Connect</Button>}
    </div>
  );
}

function SettingsScreen({ theme, setTheme, initial = "team" }) {
  const [tab, setTab] = useSetState(initial);
  useSetEffect(() => { setTab(initial); }, [initial]);
  const [standups, setStandups] = useSetState(CHANNEL_STANDUPS);

  return (
    <div className="cep-settings">
      <aside className="cep-settings-side">
        <nav className="cep-settings-nav">
          {NAV.map((n) => (
            <button key={n.id} className={"cep-settings-navitem" + (tab === n.id ? " active" : "")} onClick={() => setTab(n.id)}>
              <Icon name={n.icon} size={16} /> {n.label}
            </button>
          ))}
        </nav>
      </aside>

      <div className="cep-settings-body">
        <div className="cep-page cep-page-narrow" style={{ paddingTop: 32 }}>

          {tab === "team" ? (
            <div className="cep-fade-in">
              <div className="cep-page-head">
                <div className="cep-page-title">Team settings</div>
                <div className="cep-page-sub">Manage your workspace and preferences.</div>
              </div>

              <div className="cep-section">
                <div className="cep-section-title"><Icon name="building-2" size={15} /> Workspace</div>
                <div className="cep-card" style={{ padding: 20 }}>
                  <Field label="Workspace name">
                    <input className="cep-input" defaultValue="Acme Team" />
                  </Field>
                  <div className="cep-setting-row" style={{ paddingBottom: 0 }}>
                    <div>
                      <div className="cep-setting-label">Appearance</div>
                      <div className="cep-setting-desc">Ceptly ships dark by default. Switch the whole app instantly.</div>
                    </div>
                    <div className="cep-segment">
                      <button className={theme === "dark" ? "active" : ""} onClick={() => setTheme("dark")}><Icon name="moon" size={14} /> Dark</button>
                      <button className={theme === "light" ? "active" : ""} onClick={() => setTheme("light")}><Icon name="sun" size={14} /> Light</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="cep-section">
                <div className="cep-section-title"><Icon name="triangle-alert" size={15} /> Danger zone</div>
                <div className="cep-card" style={{ padding: 20, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 16 }}>
                  <div>
                    <div className="cep-setting-label">Delete workspace</div>
                    <div className="cep-setting-desc">Permanently remove this workspace, its schedules, and history.</div>
                  </div>
                  <Button variant="destructive">Delete</Button>
                </div>
              </div>
            </div>
          ) : null}

          {tab === "account" ? (
            <div className="cep-fade-in">
              <div className="cep-page-head">
                <div className="cep-page-title">Account</div>
                <div className="cep-page-sub">Your personal profile and sign-in.</div>
              </div>
              <div className="cep-card" style={{ padding: 20, display: "flex", flexDirection: "column", gap: 18 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                  <span className="cep-avatar cep-avatar-lg">JA</span>
                  <div>
                    <div className="cep-setting-label">Jordan Avery</div>
                    <div className="cep-setting-desc">jordan@acme.com · Founder / Executive</div>
                  </div>
                </div>
                <Field label="Full name"><input className="cep-input" defaultValue="Jordan Avery" /></Field>
                <Field label="Email"><input className="cep-input" type="email" defaultValue="jordan@acme.com" /></Field>
                <div className="cep-setting-row" style={{ paddingBottom: 0 }}>
                  <div>
                    <div className="cep-setting-label">Password</div>
                    <div className="cep-setting-desc">Last changed 3 months ago.</div>
                  </div>
                  <Button variant="outline">Change password</Button>
                </div>
              </div>
            </div>
          ) : null}

          {tab === "integrations" ? (
            <div className="cep-fade-in">
              <div className="cep-page-head">
                <div className="cep-page-title">Integrations</div>
                <div className="cep-page-sub">Connect the tools your team already uses.</div>
              </div>
              <div style={{ display: "grid", gap: 12 }}>
                {INTEGRATIONS(theme).map((it) => <IntegrationCard key={it.key} it={it} />)}
              </div>
            </div>
          ) : null}

          {tab === "standups" ? (
            <div className="cep-fade-in">
              <div className="cep-page-head">
                <div className="cep-page-title">Channel standups</div>
                <div className="cep-page-sub">Recurring standups that run in a Slack channel.</div>
              </div>
              <div className="cep-list-card">
                {standups.map((s, i) => (
                  <div className="cep-list-row" key={s.name}>
                    <span className="cep-avatar cep-avatar-sm cep-avatar-spark"><Icon name="hash" size={14} /></span>
                    <div className="cep-list-main">
                      <div className="cep-list-name">{s.name}</div>
                      <div className="cep-list-desc">{s.channel} · {s.style} · {s.cadence}</div>
                    </div>
                    <Toggle on={s.on} onChange={(v) => setStandups((cur) => cur.map((x, j) => j === i ? { ...x, on: v } : x))} />
                  </div>
                ))}
              </div>
              <div style={{ marginTop: 16 }}>
                <Button variant="outline"><Icon name="plus" size={15} /> New channel standup</Button>
              </div>
            </div>
          ) : null}

          {tab === "billing" ? (
            <div className="cep-fade-in">
              <div className="cep-page-head">
                <div className="cep-page-title">Billing</div>
                <div className="cep-page-sub">Your plan and seats.</div>
              </div>
              <div className="cep-plan">
                <div className="cep-plan-head">
                  <div>
                    <Badge variant="green" style={{ marginBottom: 10 }}>Trial · 6 days left</Badge>
                    <div className="cep-price">$20<small> / seat / month</small></div>
                  </div>
                  <Button variant="default">Subscribe via Stripe</Button>
                </div>
                <ul className="cep-plan-feats">
                  <li><Icon name="check" size={15} /> Unlimited check-ins and channel standups</li>
                  <li><Icon name="check" size={15} /> Team insights grounded in real responses</li>
                  <li><Icon name="check" size={15} /> Slack, Linear, Jira & monday.com integrations</li>
                </ul>
              </div>
              <div className="cep-stat-grid" style={{ marginTop: 20 }}>
                <div className="cep-stat"><div className="cep-stat-val">5</div><div className="cep-stat-label">Seats in use</div></div>
                <div className="cep-stat"><div className="cep-stat-val">1</div><div className="cep-stat-label">Pending invite</div></div>
                <div className="cep-stat"><div className="cep-stat-val">10</div><div className="cep-stat-label">Day free trial</div></div>
              </div>
              <p className="cep-field-hint">No credit card required during your trial.</p>
            </div>
          ) : null}

        </div>
      </div>
    </div>
  );
}

window.SettingsScreen = SettingsScreen;
