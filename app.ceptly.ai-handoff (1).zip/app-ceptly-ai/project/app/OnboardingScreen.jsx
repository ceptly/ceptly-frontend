/* global React, Icon, Button, Field, Badge */
// Ceptly App — onboarding wizard (6 steps, Slack step conditional on tool selection)

const { useState: useOnbState, useMemo: useOnbMemo } = React;

const ROLE_OPTIONS = [
  { value: "founder_executive", label: "Founder / Executive" },
  { value: "team_lead", label: "Team Lead" },
  { value: "individual_contributor", label: "Individual Contributor" },
  { value: "other", label: "Other" },
];
const REFERRAL_OPTIONS = [
  { value: "ai_tools", label: "AI Tools", description: "Claude, Perplexity, etc." },
  { value: "friend_colleague", label: "Friend / Colleague" },
  { value: "search_engine", label: "Search Engine" },
  { value: "x_twitter", label: "X (Twitter)" },
  { value: "linkedin", label: "LinkedIn" },
  { value: "other", label: "Other" },
];
const TOOL_OPTIONS = [
  { value: "slack", label: "Slack" },
  { value: "discord", label: "Discord" },
  { value: "ms_teams", label: "MS Teams" },
  { value: "linear", label: "Linear" },
  { value: "clickup", label: "ClickUp" },
  { value: "monday", label: "monday.com" },
  { value: "notion", label: "Notion" },
];

function OptionSelector({ options, value, onChange, multi = false }) {
  function toggle(v) {
    if (multi) {
      const set = new Set(value);
      set.has(v) ? set.delete(v) : set.add(v);
      onChange([...set]);
    } else onChange(v);
  }
  const isSel = (v) => (multi ? value.includes(v) : value === v);
  return (
    <div className="cep-options">
      {options.map((o) => (
        <button type="button" key={o.value}
          className={"cep-option" + (isSel(o.value) ? " sel" : "")}
          onClick={() => toggle(o.value)}>
          <span className={"cep-option-check" + (multi ? " cep-option-box" : "")}>
            {isSel(o.value) ? <Icon name="check" size={12} /> : null}
          </span>
          <span className="cep-option-main">
            <span className="cep-option-label">{o.label}</span>
            {o.description ? <span className="cep-option-desc">{o.description}</span> : null}
          </span>
        </button>
      ))}
    </div>
  );
}

function OnboardingScreen({ onFinish, user }) {
  const [step, setStep] = useOnbState(1);
  const [role, setRole] = useOnbState(null);
  const [referral, setReferral] = useOnbState(null);
  const [invites, setInvites] = useOnbState([]);
  const [inviteInput, setInviteInput] = useOnbState("");
  const [tools, setTools] = useOnbState([]);
  const [org, setOrg] = useOnbState(user?.org || "Acme Inc.");
  const [slackDone, setSlackDone] = useOnbState(false);

  const slackSelected = tools.includes("slack");
  const totalSteps = slackSelected ? 6 : 5;
  const pct = (step / totalSteps) * 100;

  function addInvite() {
    const v = inviteInput.trim().toLowerCase();
    if (!v || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) || invites.includes(v)) { setInviteInput(""); return; }
    setInvites([...invites, v]); setInviteInput("");
  }

  function next() {
    if (step < totalSteps) setStep(step + 1);
    else onFinish({ org });
  }
  function back() { if (step > 1) setStep(step - 1); }

  const titles = {
    1: "What is your role?",
    2: "How did you hear about us?",
    3: "Invite people to your workspace",
    4: "Which tools does your team use?",
    5: "What's your organization name?",
    6: "Connect Ceptly to Slack",
  };
  const descs = {
    1: "This helps us tailor Ceptly to how you work.",
    2: "We'd love to know where you discovered Ceptly.",
    3: "Add teammates by email. You can always invite more later.",
    4: "Select all that apply. We'll prioritize integrations accordingly.",
    5: "This is how your workspace will appear in Ceptly.",
    6: "Check-ins run in Slack DMs. Connect your workspace now or skip and set this up later in Settings.",
  };

  const canContinue =
    (step === 1 && role) || (step === 2 && referral) || step === 3 || step === 4 ||
    (step === 5 && org.trim()) || step === 6;

  const continueLabel = step === totalSteps ? "Finish setup" : "Continue";

  return (
    <div className="cep-onb">
      <div className="cep-auth-bg">
        <div className="cep-grid-layer" />
        <div className="cep-dot-layer" />
      </div>
      <div className="cep-onb-card-wrap">
        <div className="cep-onb-card">
          <div className="cep-step-eyebrow">Step {step} of {totalSteps}</div>
          <div className="cep-progress"><div className="cep-progress-fill" style={{ width: pct + "%" }} /></div>

          <div className="cep-onb-head">
            <h2>{titles[step]}</h2>
            <p>{descs[step]}</p>
          </div>

          <div key={step} className="cep-fade-in">
            {step === 1 ? <OptionSelector options={ROLE_OPTIONS} value={role} onChange={setRole} /> : null}
            {step === 2 ? <OptionSelector options={REFERRAL_OPTIONS} value={referral} onChange={setReferral} /> : null}
            {step === 3 ? (
              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                <div style={{ display: "flex", gap: 8 }}>
                  <div className="cep-input-wrap" style={{ flex: 1 }}>
                    <span className="cep-input-icon"><Icon name="mail" size={16} /></span>
                    <input className="cep-input" type="email" value={inviteInput} placeholder="teammate@company.com"
                      onChange={(e) => setInviteInput(e.target.value)}
                      onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addInvite(); } }} />
                  </div>
                  <Button type="button" variant="outline" onClick={addInvite}>Add</Button>
                </div>
                {invites.length ? (
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                    {invites.map((em) => (
                      <span className="cep-chip-removable" key={em}>{em}
                        <button onClick={() => setInvites(invites.filter((x) => x !== em))} aria-label="Remove"><Icon name="x" size={12} /></button>
                      </span>
                    ))}
                  </div>
                ) : <p className="cep-field-hint" style={{ marginTop: 0 }}>No invites added yet. You can skip this step.</p>}
              </div>
            ) : null}
            {step === 4 ? <OptionSelector options={TOOL_OPTIONS} value={tools} onChange={setTools} multi /> : null}
            {step === 5 ? (
              <Field label="Organization name" id="org">
                <input id="org" className="cep-input" value={org} onChange={(e) => setOrg(e.target.value)} placeholder="Acme Inc." />
              </Field>
            ) : null}
            {step === 6 ? (
              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                {slackDone ? (
                  <div className="cep-alert cep-alert-success"><Icon name="check-circle-2" size={16} />
                    <div>Slack connected successfully. You can add team members from Settings after setup.</div></div>
                ) : (
                  <div className="cep-slack-callout">
                    <img src="assets/integrations/slack.png" alt="Slack" />
                    <p style={{ fontSize: 13, color: "var(--fg2)", margin: 0, lineHeight: 1.5 }}>
                      Install Ceptly in your Slack workspace so scheduled check-ins reach your team in DMs.</p>
                  </div>
                )}
                {!slackDone ? <Button type="button" variant="default" onClick={() => setSlackDone(true)}>Add to Slack</Button> : null}
              </div>
            ) : null}
          </div>

          <div className="cep-onb-foot">
            {step > 1 ? <Button variant="outline" onClick={back}>Back</Button> : <span />}
            <div style={{ display: "flex", gap: 8 }}>
              {step === 3 ? <Button variant="ghost" onClick={() => setStep(4)}>Skip</Button> : null}
              {step === 6 && !slackDone ? <Button variant="ghost" onClick={() => onFinish({ org })}>Skip for now</Button> : null}
              <Button variant="default" onClick={next} disabled={!canContinue}>{continueLabel}</Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

window.OnboardingScreen = OnboardingScreen;
