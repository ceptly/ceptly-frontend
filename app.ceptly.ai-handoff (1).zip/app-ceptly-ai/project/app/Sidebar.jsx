/* global React, Icon, useClickOutside */
// Ceptly App — left sidebar navigation (desktop). Holds logo, nav, and account menu.

function AppSidebar({ active, onNavigate, onSignOut, workspaceName = "Acme Team", user, theme = "dark", attentionCount = 2 }) {
  const [open, setOpen] = React.useState(false);
  const ref = useClickOutside(() => setOpen(false));
  const items = [
    { id: "chat", label: "Chat", icon: "message-square" },
    { id: "activity", label: "Activity", icon: "activity", badge: attentionCount },
    { id: "agents", label: "Agents", icon: "bot" },
    { id: "team", label: "Team", icon: "users" },
    { id: "settings", label: "Settings", icon: "settings" },
  ];
  function go(id, sub) { setOpen(false); onNavigate(id, sub); }
  return (
    <aside className="cep-side">
      <div className="cep-side-brand" onClick={() => onNavigate("chat")} title="Ceptly">
        <span className="cep-side-logo">
          <img src={theme === "light" ? "assets/parallax-light.png" : "assets/parallax-dark.png"} alt="Ceptly" />
        </span>
        <span className="cep-side-wordmark">Ceptly</span>
      </div>

      <button className="cep-side-ws" onClick={() => onNavigate("settings")}>
        <span className="cep-side-ws-mark">{workspaceName.slice(0, 1)}</span>
        <span className="cep-side-ws-name">{workspaceName}</span>
        <Icon name="chevron-down" size={15} />
      </button>

      <nav className="cep-side-nav">
        {items.map((it) => (
          <button key={it.id}
            className={"cep-side-item" + (active === it.id ? " active" : "")}
            onClick={() => onNavigate(it.id)}>
            <Icon name={it.icon} size={17} />
            <span className="cep-side-item-label">{it.label}</span>
            {it.badge && active !== it.id ? (
              <span className="cep-side-badge">{it.badge > 9 ? "9+" : it.badge}</span>
            ) : null}
          </button>
        ))}
      </nav>

      <div className="cep-side-foot" ref={ref}>
        {open ? (
          <div className="cep-menu cep-side-menu cep-fade-in">
            <button className="cep-menu-item" onClick={() => go("settings")}>
              <Icon name="settings-2" size={15} /> Team settings
            </button>
            <button className="cep-menu-item" onClick={() => go("settings", "account")}>
              <Icon name="user" size={15} /> Account
            </button>
            <div className="cep-menu-sep" />
            <button className="cep-menu-item" onClick={() => { setOpen(false); onSignOut(); }}>
              <Icon name="log-out" size={15} /> Sign out
            </button>
          </div>
        ) : null}
        <button className={"cep-side-user" + (open ? " open" : "")} onClick={() => setOpen((o) => !o)}>
          <span className="cep-avatar cep-avatar-sm">{user.initials}</span>
          <span className="cep-side-user-text">
            <span className="cep-side-user-name">{user.name}</span>
            <span className="cep-side-user-mail">{user.email}</span>
          </span>
          <Icon name="chevrons-up-down" size={15} />
        </button>
      </div>
    </aside>
  );
}

window.AppSidebar = AppSidebar;
